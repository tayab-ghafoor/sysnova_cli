# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""
Backup Service - Application Layer

Orchestrates backup operations including manual backups, scheduled backups, and cloud uploads.
Calls core modules for backup logic and infrastructure for storage and notifications.
"""

from typing import Dict, Any, List, Optional
from pathlib import Path
from ..core.validator import validate_path_exists, validate_backup_drive
from ..core.Backup_manager import _run_backup_operation
from ..core.Backup_system_manager import BackupManager
from ..core.google_drive_manager import google_drive_manager
from ..core.rclon_manager import rclone_manager
from ..ulits.logger import get_logger
from ..Notifications.Emailer import send_backup_completion_email

logger = get_logger(__name__)


def run_backup(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Orchestrates backup operations

    Args:
        config: Configuration dict containing:
            - sources: List of paths to backup
            - destination: Backup destination drive/path
            - format: 'zip' or 'folder'
            - compress: Boolean for compression
            - cloud_upload: Optional cloud upload config

    Returns:
        dict: Backup results with success status and details
    """
    try:
        sources = config.get("sources", [])
        if not sources:
            return {"success": False, "message": "No backup sources specified"}

        destination = config.get("destination")
        format_type = config.get("format", "zip")
        compress = config.get("compress", True)
        cloud_config = config.get("cloud_upload")

        logger.info(f"Starting backup for {len(sources)} source(s)")

        # Validate sources
        for source in sources:
            if not validate_path_exists(source):
                return {"success": False, "message": f"Source path does not exist: {source}"}

        # Validate destination if specified
        if destination and not validate_path_exists(destination, path_type="directory"):
            return {"success": False, "message": f"Destination path does not exist: {destination}"}

        # Run backup operation (core)
        backup_results = []
        for source in sources:
            try:
                backup_mgr = BackupManager(source, destination)
                backup_path = backup_mgr.create_backup(compress=compress)

                if backup_path:
                    result = {
                        "source": source,
                        "backup_path": str(backup_path),
                        "success": True
                    }

                    # Handle cloud upload if configured
                    if cloud_config:
                        cloud_result = _handle_cloud_upload(backup_path, cloud_config)
                        result["cloud_upload"] = cloud_result

                    backup_results.append(result)
                else:
                    backup_results.append({
                        "source": source,
                        "success": False,
                        "message": "Backup creation failed"
                    })

            except Exception as e:
                logger.error(f"Backup failed for {source}: {str(e)}")
                backup_results.append({
                    "source": source,
                    "success": False,
                    "message": str(e)
                })

        # Send notifications if configured
        successful_backups = [r for r in backup_results if r["success"]]
        if successful_backups and config.get("notify_email"):
            _send_backup_notifications(successful_backups, config["notify_email"])

        return {
            "success": len(successful_backups) > 0,
            "total_sources": len(sources),
            "successful_backups": len(successful_backups),
            "results": backup_results
        }

    except Exception as e:
        logger.error(f"Backup operation failed: {str(e)}")
        return {"success": False, "message": f"Backup failed: {str(e)}"}


def list_backups(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Lists existing backups for sources

    Args:
        config: Configuration dict containing:
            - sources: List of source paths to check

    Returns:
        dict: Backup listing results
    """
    try:
        sources = config.get("sources", [])
        if not sources:
            return {"success": False, "message": "No sources specified"}

        all_backups = []
        for source in sources:
            try:
                backup_mgr = BackupManager(source)
                existing_backups = backup_mgr.get_existing_backups()

                backups_info = []
                for backup in existing_backups:
                    size = 0
                    if backup.is_file():
                        size = backup.stat().st_size
                    elif backup.is_dir():
                        for item in backup.rglob('*'):
                            if item.is_file():
                                size += item.stat().st_size

                    backups_info.append({
                        "path": str(backup),
                        "size_mb": size / (1024 * 1024),
                        "type": "zip" if backup.suffix == '.zip' else "folder"
                    })

                all_backups.append({
                    "source": source,
                    "backups": backups_info
                })

            except Exception as e:
                logger.error(f"Error listing backups for {source}: {str(e)}")
                all_backups.append({
                    "source": source,
                    "error": str(e)
                })

        return {
            "success": True,
            "backups": all_backups
        }

    except Exception as e:
        logger.error(f"List backups failed: {str(e)}")
        return {"success": False, "message": str(e)}


def _handle_cloud_upload(backup_path: Path, cloud_config: Dict[str, Any]) -> Dict[str, Any]:
    """Handle cloud upload for backup"""
    try:
        upload_type = cloud_config.get("type", "google_drive")

        if upload_type == "google_drive":
            success = google_drive_manager.upload_backup(str(backup_path))
        elif upload_type == "rclone":
            remote_name = cloud_config.get("remote_name", "gdrive")
            success = rclone_manager.upload_backup(str(backup_path), remote_name)
        else:
            return {"success": False, "message": f"Unsupported upload type: {upload_type}"}

        return {
            "success": success,
            "type": upload_type,
            "message": "Upload completed" if success else "Upload failed"
        }

    except Exception as e:
        logger.error(f"Cloud upload failed: {str(e)}")
        return {"success": False, "message": str(e)}


def _send_backup_notifications(backup_results: List[Dict[str, Any]], email: str) -> None:
    """Send backup completion notifications"""
    try:
        for result in backup_results:
            backup_path = result.get("backup_path")
            if backup_path:
                # Calculate size
                path_obj = Path(backup_path)
                size = 0
                if path_obj.is_file():
                    size = path_obj.stat().st_size
                elif path_obj.is_dir():
                    for item in path_obj.rglob('*'):
                        if item.is_file():
                            size += item.stat().st_size

                send_backup_completion_email(
                    email,
                    result["source"],
                    backup_path,
                    size / (1024 * 1024),
                    "Manual"
                )
    except Exception as e:
        logger.warning(f"Failed to send backup notification: {str(e)}")
<parameter name="filePath">d:\SystemManagerCLI\src\system_manager_cli\application\backup_service.py