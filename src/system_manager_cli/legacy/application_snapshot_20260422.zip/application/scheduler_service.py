# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""
Scheduler Service - Application Layer

Orchestrates task scheduling operations including creating, managing, and monitoring scheduled tasks.
Calls core modules for scheduler logic and infrastructure for persistence and notifications.
"""

from typing import Dict, Any, List, Callable, Optional
from ..core.scheduler_core import TaskScheduler
from ..core.validator import validate_task_id
from ..ulits.logger import get_logger
from ..Notifications.Emailer import send_task_completion_email

logger = get_logger(__name__)


def schedule_task(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Orchestrates task scheduling

    Args:
        config: Configuration dict containing:
            - task_id: Unique task identifier
            - action: Task action/function name
            - interval: Time interval
            - unit: Time unit ('seconds', 'minutes', 'hours', 'days', 'weeks')
            - at_time: Optional specific time (HH:MM)
            - weekday: Optional weekday
            - day_of_month: Optional day of month
            - args: Optional positional arguments
            - kwargs: Optional keyword arguments
            - notify_email: Optional email for notifications

    Returns:
        dict: Scheduling result with success status
    """
    try:
        task_id = config.get("task_id")
        if not validate_task_id(task_id):
            return {"success": False, "message": "Invalid task ID"}

        action_name = config.get("action")
        if not action_name:
            return {"success": False, "message": "Task action is required"}

        interval = config.get("interval", 1)
        unit = config.get("unit", "days")
        at_time = config.get("at_time")
        weekday = config.get("weekday")
        day_of_month = config.get("day_of_month")
        args = config.get("args", [])
        kwargs = config.get("kwargs", {})
        notify_email = config.get("notify_email")

        # Resolve action function
        action_func = _resolve_action_function(action_name)
        if not action_func:
            return {"success": False, "message": f"Action function '{action_name}' not found"}

        # Create task wrapper with notification
        def task_wrapper():
            try:
                result = action_func(*args, **kwargs)
                logger.info(f"Scheduled task {task_id} completed successfully")

                # Send notification if configured
                if notify_email:
                    _send_task_notification(task_id, notify_email, "SUCCESS")

                return result
            except Exception as e:
                logger.error(f"Scheduled task {task_id} failed: {str(e)}")

                # Send failure notification if configured
                if notify_email:
                    _send_task_notification(task_id, notify_email, "FAILED", str(e))

                raise

        # Get scheduler instance
        scheduler = TaskScheduler()

        # Add the task
        scheduler.add_task(
            task_id=task_id,
            task_func=task_wrapper,
            interval=interval,
            unit=unit,
            at_time=at_time,
            weekday=weekday,
            day_of_month=day_of_month
        )

        # Store additional metadata
        if scheduler.tasks.get(task_id):
            scheduler.tasks[task_id].update({
                'action_name': action_name,
                'action_args': args,
                'action_kwargs': kwargs,
                'user_email': notify_email
            })
            scheduler._save_task_metadata(task_id)

        logger.info(f"Task scheduled successfully: {task_id}")
        return {
            "success": True,
            "message": f"Task '{task_id}' scheduled successfully",
            "task_id": task_id
        }

    except Exception as e:
        logger.error(f"Failed to schedule task: {str(e)}")
        return {"success": False, "message": f"Scheduling failed: {str(e)}"}


def remove_scheduled_task(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Removes a scheduled task

    Args:
        config: Configuration dict containing:
            - task_id: Task identifier to remove

    Returns:
        dict: Removal result
    """
    try:
        task_id = config.get("task_id")
        if not task_id:
            return {"success": False, "message": "Task ID is required"}

        scheduler = TaskScheduler()
        success = scheduler.remove_task(task_id)

        if success:
            logger.info(f"Task removed successfully: {task_id}")
            return {
                "success": True,
                "message": f"Task '{task_id}' removed successfully"
            }
        else:
            return {"success": False, "message": f"Task '{task_id}' not found"}

    except Exception as e:
        logger.error(f"Failed to remove task: {str(e)}")
        return {"success": False, "message": str(e)}


def list_scheduled_tasks(config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Lists all scheduled tasks

    Returns:
        dict: Task listing with details
    """
    try:
        scheduler = TaskScheduler()
        tasks = scheduler.list_tasks()
        next_runs = scheduler.get_next_runs()

        task_details = []
        for task_id, schedule_desc in tasks.items():
            task_info = scheduler.tasks.get(task_id, {})
            next_run_info = None

            # Find next run for this task
            for run_info in next_runs:
                if hasattr(run_info['job'], 'job_func') and task_id in str(run_info['job'].job_func):
                    next_run_info = {
                        "next_run": run_info['next_run'].isoformat() if run_info['next_run'] else None,
                        "idle_seconds": run_info['idle_seconds']
                    }
                    break

            task_details.append({
                "task_id": task_id,
                "schedule": schedule_desc,
                "action": task_info.get('action_name', 'Unknown'),
                "next_run": next_run_info
            })

        return {
            "success": True,
            "tasks": task_details,
            "total_tasks": len(task_details)
        }

    except Exception as e:
        logger.error(f"Failed to list tasks: {str(e)}")
        return {"success": False, "message": str(e)}


def start_scheduler(config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Starts the task scheduler

    Returns:
        dict: Start result
    """
    try:
        scheduler = TaskScheduler()
        scheduler.start()

        return {
            "success": True,
            "message": "Scheduler started successfully"
        }

    except Exception as e:
        logger.error(f"Failed to start scheduler: {str(e)}")
        return {"success": False, "message": str(e)}


def stop_scheduler(config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Stops the task scheduler

    Returns:
        dict: Stop result
    """
    try:
        scheduler = TaskScheduler()
        scheduler.stop()

        return {
            "success": True,
            "message": "Scheduler stopped successfully"
        }

    except Exception as e:
        logger.error(f"Failed to stop scheduler: {str(e)}")
        return {"success": False, "message": str(e)}


def _resolve_action_function(action_name: str) -> Optional[Callable]:
    """Resolve action function by name"""
    try:
        # Try to import from main module
        import sys
        main_module = sys.modules.get("__main__")
        if main_module and hasattr(main_module, action_name):
            return getattr(main_module, action_name)

        # Try common action modules
        action_modules = [
            'backup_actions',
            'log_actions',
            'system_actions'
        ]

        for module_name in action_modules:
            try:
                module = __import__(f"system_manager_cli.cli.{module_name}", fromlist=[action_name])
                if hasattr(module, action_name):
                    return getattr(module, action_name)
            except ImportError:
                continue

        return None

    except Exception as e:
        logger.error(f"Error resolving action function '{action_name}': {str(e)}")
        return None


def _send_task_notification(task_id: str, email: str, status: str, error_msg: str = None) -> None:
    """Send task completion notification"""
    try:
        task_description = f"Scheduled task: {task_id}"
        if error_msg:
            task_description += f" - Error: {error_msg}"

        send_task_completion_email(
            email,
            task_id,
            task_description,
            "Scheduled execution",
            "Completed",
            status
        )
    except Exception as e:
        logger.warning(f"Failed to send task notification: {str(e)}")
<parameter name="filePath">d:\SystemManagerCLI\src\system_manager_cli\application\scheduler_service.py