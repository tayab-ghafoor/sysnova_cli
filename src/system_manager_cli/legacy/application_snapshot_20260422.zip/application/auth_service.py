# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""
Authentication Service - Application Layer

Orchestrates user authentication, registration, and session management.
Calls core modules for validation and business logic.
"""

from typing import Dict, Any, Optional
from ..core.validator import validate_email, validate_password
from ..core.Auth import hash_password, verify_password
from ..config.app_config import get_config
from ..infrastructure.logger import get_logger
from ..infrastructure.notifications.Emailer import send_email

logger = get_logger(__name__)


class AuthService:
    """Service for handling authentication operations"""

    def __init__(self):
        self.config = get_config()

    def register_user(self, email: str, password: str, name: str = "") -> Dict[str, Any]:
        """
        Orchestrates user registration process

        Args:
            email: User email
            password: User password
            name: Optional user name

        Returns:
            dict: Registration result with success status and message
        """
        try:
            # Validate inputs using core validator
            if not validate_email(email):
                return {"success": False, "message": "Invalid email format"}

            if not validate_password(password):
                return {"success": False, "message": "Password does not meet requirements"}

            # Hash password using core auth logic
            hashed_password = hash_password(password)

            # Create user data
            user_data = {
                "email": email,
                "password_hash": hashed_password,
                "name": name,
                "created_at": self._get_current_time(),
                "is_active": True
            }

            # Save user (this would call infrastructure layer)
            # For now, placeholder
            save_result = self._save_user(user_data)

            if not save_result["success"]:
                return save_result

            # Send welcome email
            self._send_welcome_email(email, name)

            logger.info(f"User registered successfully: {email}")
            return {"success": True, "message": "User registered successfully"}

        except Exception as e:
            logger.error(f"Registration failed for {email}: {str(e)}")
            return {"success": False, "message": "Registration failed"}

    def login_user(self, email: str, password: str) -> Dict[str, Any]:
        """
        Orchestrates user login process

        Args:
            email: User email
            password: User password

        Returns:
            dict: Login result with success status, user data, and token
        """
        try:
            # Get user data (would call infrastructure)
            user_data = self._get_user_by_email(email)

            if not user_data:
                return {"success": False, "message": "User not found"}

            # Verify password using core logic
            if not verify_password(password, user_data["password_hash"]):
                return {"success": False, "message": "Invalid password"}

            # Create session token
            token = self._create_session_token(user_data)

            # Save session (infrastructure)
            self._save_session(email, token)

            logger.info(f"User logged in: {email}")
            return {
                "success": True,
                "message": "Login successful",
                "email": email,
                "name": user_data.get("name", ""),
                "token": token
            }

        except Exception as e:
            logger.error(f"Login failed for {email}: {str(e)}")
            return {"success": False, "message": "Login failed"}

    def reset_password(self, email: str) -> Dict[str, Any]:
        """
        Initiates password reset process

        Args:
            email: User email

        Returns:
            dict: Reset result
        """
        try:
            # Check if user exists
            user_data = self._get_user_by_email(email)
            if not user_data:
                # Don't reveal if user exists or not for security
                return {"success": True, "message": "If the email exists, a reset code has been sent"}

            # Generate reset code
            reset_code = self._generate_reset_code()

            # Save reset code with expiry
            self._save_reset_code(email, reset_code)

            # Send reset email
            self._send_reset_email(email, reset_code)

            logger.info(f"Password reset initiated for: {email}")
            return {"success": True, "message": "Reset code sent to email"}

        except Exception as e:
            logger.error(f"Password reset failed for {email}: {str(e)}")
            return {"success": False, "message": "Password reset failed"}

    def _save_user(self, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Placeholder for saving user to infrastructure layer"""
        # This would call infrastructure/user_repository.py or similar
        return {"success": True}

    def _get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Placeholder for getting user from infrastructure layer"""
        # This would call infrastructure/user_repository.py
        return None

    def _create_session_token(self, user_data: Dict[str, Any]) -> str:
        """Placeholder for session token creation"""
        # This would use core/session_logic.py
        return "mock_token"

    def _save_session(self, email: str, token: str) -> None:
        """Placeholder for saving session"""
        pass

    def _generate_reset_code(self) -> str:
        """Placeholder for reset code generation"""
        return "123456"

    def _save_reset_code(self, email: str, code: str) -> None:
        """Placeholder for saving reset code"""
        pass

    def _send_welcome_email(self, email: str, name: str) -> None:
        """Send welcome email using infrastructure"""
        try:
            subject = "Welcome to System Manager CLI"
            body = f"Hello {name},\n\nWelcome to System Manager CLI!"
            send_email(email, subject, body)
        except Exception as e:
            logger.warning(f"Failed to send welcome email: {str(e)}")

    def _send_reset_email(self, email: str, code: str) -> None:
        """Send password reset email"""
        try:
            subject = "Password Reset Code"
            body = f"Your reset code is: {code}\n\nThis code expires in 5 minutes."
            send_email(email, subject, body)
        except Exception as e:
            logger.warning(f"Failed to send reset email: {str(e)}")

    def _get_current_time(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().isoformat()


# Convenience functions for CLI layer
def register_user(email: str, password: str, name: str = "") -> Dict[str, Any]:
    """Convenience function for user registration"""
    service = AuthService()
    return service.register_user(email, password, name)


def login_user(email: str, password: str) -> Dict[str, Any]:
    """Convenience function for user login"""
    service = AuthService()
    return service.login_user(email, password)


def reset_password(email: str) -> Dict[str, Any]:
    """Convenience function for password reset"""
    service = AuthService()
    return service.reset_password(email)