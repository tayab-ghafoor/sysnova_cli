# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""
Log Analysis Service - Application Layer

Orchestrates the full log analysis pipeline.
Calls core modules for reading, scrubbing, aggregating, analyzing, correlating, anomaly detection, and recommendations.
"""

from typing import Dict, Any, List
from ..core.validator import validate_path_exists
from ..Analysis.reader import parse_log_line, filter_log_entries, extract_metadata_from_logs
from ..Analysis.scrubber import scrub_lines
from ..Analysis.aggregate import aggregate_logs
from ..Analysis.analyzer import analyze_log_patterns
from ..ulits.logger import get_logger
from ..ulits.file_utils import read_file_lines

logger = get_logger(__name__)


def run_log_analysis(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Orchestrates the full log analysis pipeline

    Args:
        config: Configuration dict containing:
            - path: Log file path
            - format: Log format ('default', 'apache', 'syslog')
            - filters: Optional filters dict
            - scrub_sensitive: Boolean to scrub sensitive data

    Returns:
        dict: Analysis results with metadata, patterns, anomalies, recommendations
    """
    try:
        # Validate input
        try:
            log_path_obj = validate_path_exists(config.get("path", ""), path_type="file")
            log_path = str(log_path_obj)
        except Exception as e:
            return {"success": False, "message": f"Invalid log path: {str(e)}"}

        log_path = config["path"]
        log_format = config.get("format", "default")
        filters = config.get("filters", {})
        scrub_sensitive = config.get("scrub_sensitive", True)

        logger.info(f"Starting log analysis for: {log_path}")

        # Step 1: Read raw log lines from file (infrastructure)
        raw_lines = read_file_lines(log_path)
        if not raw_lines:
            return {"success": False, "message": "No log data found"}

        # Step 2: Scrub sensitive data if requested (core)
        if scrub_sensitive:
            scrubbed_lines = scrub_lines(raw_lines)
        else:
            scrubbed_lines = raw_lines

        # Step 3: Parse log entries (core)
        log_entries = []
        for line in scrubbed_lines:
            try:
                entry = parse_log_line(line, log_format)
                log_entries.append(entry)
            except ValueError:
                # Skip unparseable lines
                continue

        if not log_entries:
            return {"success": False, "message": "No valid log entries found"}

        # Step 4: Apply filters (core)
        filtered_entries = filter_log_entries(log_entries, filters)

        # Step 5: Aggregate data (core)
        aggregated_data = aggregate_logs(filtered_entries)

        # Step 6: Analyze patterns (core)
        patterns = analyze_log_patterns(filtered_entries)

        # Step 7: Detect anomalies (core)
        from ..Analysis.correlater import Correlator
        from ..Analysis.anomaly import AnomalyDetector
        from ..Analysis.recommender import Recommender
        
        anomalies = AnomalyDetector().detect_anomalies(filtered_entries)

        # Step 8: Generate correlations (core)
        correlations = Correlator().correlate_events(filtered_entries)

        # Step 9: Get recommendations (core)
        recommendations = Recommender().get_recommendations(anomalies, filtered_entries)

        # Step 10: Extract metadata (core)
        metadata = extract_metadata_from_logs(filtered_entries)

        result = {
            "success": True,
            "metadata": metadata,
            "patterns": [p.to_dict() for p in patterns],
            "anomalies": [a.__dict__ if hasattr(a, '__dict__') else str(a) for a in anomalies],
            "correlations": [c.__dict__ if hasattr(c, '__dict__') else str(c) for c in correlations],
            "recommendations": [r.__dict__ if hasattr(r, '__dict__') else str(r) for r in recommendations],
            "aggregated_data": aggregated_data
        }

        logger.info(f"Log analysis completed successfully for: {log_path}")
        return result

    except Exception as e:
        logger.error(f"Log analysis failed: {str(e)}")
        return {"success": False, "message": f"Analysis failed: {str(e)}"}