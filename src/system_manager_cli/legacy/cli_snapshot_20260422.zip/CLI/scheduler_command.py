# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
import time
import click
from typing import Optional

from system_manager_cli.CLI.auth_command import cli
from ..core import cli
from system_manager_cli.CLI.utils import require_login, handle_error
from core.validator import validate_path_exists, validate_path_readable, PathError       
from auth_command import current_user, is_user_logged_in, task_scheduler, logger, Config

from  system_manager_cli.core.scheduler import scheduled_health_check, scheduled_backup, scheduled_cleanup, scheduled_log_analysis, run_async_tasks, async_health_check



@cli.command()
@click.option('--task', type=click.Choice(['health', 'backup', 'cleanup', 'report']), 
              help='Type of task to schedule')
@click.option('--interval', type=int, default=1, help='How often to run')
@click.option('--unit', type=click.Choice(['seconds', 'minutes', 'hours', 'days', 'weeks']), 
              default='hours', help='Time unit')
@click.option('--time', 'time_str', type=str, help='Clock time for the job (HH:MM)')
@click.option('--frequency', type=click.Choice(['daily','weekly','monthly']), default='daily',
              help='High‑level frequency (used together with --time)')
@click.option('--weekday', type=click.Choice(['monday','tuesday','wednesday','thursday','friday','saturday','sunday']),
              help='Weekday when --frequency=weekly')
@click.option('--day', 'day_of_month', type=int, help='Day of month when --frequency=monthly')
@click.option('--folder', type=click.Path(exists=True), help='Folder path (for backup/cleanup)')
@click.option('--log-path', type=click.Path(exists=True), help='Log path (for report task)')
def schedule_task(task: str, interval: int, unit: str, time_str: Optional[str],
                 frequency: str, weekday: Optional[str], day_of_month: Optional[int],
                 folder: Optional[str], 
                 log_path: Optional[str]) -> None:
    """
    Schedule automated tasks to run periodically
    
    Examples:
      schedule-task --task health --interval 30 --unit minutes
      schedule-task --task backup --interval 1 --unit days --folder /path/to/folder
      schedule-task --task cleanup --interval 2 --unit hours --folder /path/to/folder
    """
    if not require_login():
        return
    try:
        if not task:
            click.secho("❌ Error: --task is required", fg='red')
            return

        task_id = f"{task}_{int(time.time())}"

        # build descriptive schedule string for emails
        schedule_desc = f"{interval} {unit}"
        if time_str:
            schedule_desc += f" at {time_str}"
        if frequency == 'weekly' and weekday:
            schedule_desc = f"every {weekday}"
        elif frequency == 'monthly' and day_of_month:
            schedule_desc = f"day {day_of_month} of every month"

        user_email = current_user.get('email') if is_user_logged_in() else None
        if not user_email:
            user_email = Config.EMAIL_RECIPIENT

        if task == 'health':
            task_scheduler.add_task(
                task_id,
                scheduled_health_check,
                interval,
                unit,
                at_time=time_str,
                weekday=weekday if frequency == 'weekly' else None,
                day_of_month=day_of_month if frequency == 'monthly' else None,
            )
            if task_id in task_scheduler.tasks:
                task_scheduler.tasks[task_id]['action_name'] = 'scheduled_health_check'
                task_scheduler.tasks[task_id]['action_args'] = [schedule_desc]
                task_scheduler.tasks[task_id]['action_kwargs'] = {}
                if user_email:
                    task_scheduler.tasks[task_id]['user_email'] = user_email
            click.secho(f"✅ Health check scheduled: every {interval} {unit}", fg='green')

        elif task == 'backup':
            if not folder:
                click.secho("❌ Error: --folder is required for backup task", fg='red')
                return

            google_drive_choice = click.confirm(
                "Do you want to backup data on Google drive? (Y/N)",
                default=False
            )

            if time_str:
                task_scheduler.add_task(
                    task_id,
                    lambda f=folder, sd=schedule_desc, ue=user_email, gd=google_drive_choice: scheduled_backup(f, sd, ue, gd),
                    interval,
                    unit,
                    at_time=time_str,
                    weekday=weekday if frequency == 'weekly' else None,
                    day_of_month=day_of_month if frequency == 'monthly' else None,
                )
            else:
                task_scheduler.add_task(
                    task_id,
                    lambda f=folder, sd=schedule_desc, ue=user_email, gd=google_drive_choice: scheduled_backup(f, sd, ue, gd),
                    interval,
                    unit,
                )
            if task_id in task_scheduler.tasks:
                task_scheduler.tasks[task_id]['action_name'] = 'scheduled_backup'
                task_scheduler.tasks[task_id]['action_args'] = [folder, schedule_desc, user_email, google_drive_choice]
                task_scheduler.tasks[task_id]['action_kwargs'] = {}
                if user_email:
                    task_scheduler.tasks[task_id]['user_email'] = user_email
            click.secho(f"✅ Backup scheduled: {folder} every {interval} {unit}", fg='green')

        elif task == 'cleanup':
            if not folder:
                click.secho("❌ Error: --folder is required for cleanup task", fg='red')
                return
            if time_str:
                task_scheduler.add_task(
                    task_id,
                    lambda f=folder, sd=schedule_desc: scheduled_cleanup(f, sd),
                    interval,
                    unit,
                    at_time=time_str,
                    weekday=weekday if frequency == 'weekly' else None,
                    day_of_month=day_of_month if frequency == 'monthly' else None,
                )
            else:
                task_scheduler.add_task(
                    task_id,
                    lambda f=folder, sd=schedule_desc: scheduled_cleanup(f, sd),
                    interval,
                    unit,
                )
            if task_id in task_scheduler.tasks:
                task_scheduler.tasks[task_id]['action_name'] = 'scheduled_cleanup'
                task_scheduler.tasks[task_id]['action_args'] = [folder, schedule_desc, user_email]
                task_scheduler.tasks[task_id]['action_kwargs'] = {}
                if user_email:
                    task_scheduler.tasks[task_id]['user_email'] = user_email
            click.secho(f"✅ Cleanup scheduled: {folder} every {interval} {unit}", fg='green')

        elif task == 'report':
            if not log_path:
                click.secho("❌ Error: --log-path is required for report task", fg='red')
                return
            if time_str:
                task_scheduler.add_task(
                    task_id,
                    lambda lp=log_path, sd=schedule_desc: scheduled_log_analysis(lp, sd),
                    interval,
                    unit,
                    at_time=time_str,
                    weekday=weekday if frequency == 'weekly' else None,
                    day_of_month=day_of_month if frequency == 'monthly' else None,
                )
            else:
                task_scheduler.add_task(
                    task_id,
                    lambda lp=log_path, sd=schedule_desc: scheduled_log_analysis(lp, sd),
                    interval,
                    unit,
                )
            if task_id in task_scheduler.tasks:
                task_scheduler.tasks[task_id]['action_name'] = 'scheduled_log_analysis'
                task_scheduler.tasks[task_id]['action_args'] = [log_path, schedule_desc]
                task_scheduler.tasks[task_id]['action_kwargs'] = {}
                if user_email:
                    task_scheduler.tasks[task_id]['user_email'] = user_email
            click.secho(f" Log analysis scheduled: {log_path} every {interval} {unit}", fg='green')

        if task_id in task_scheduler.tasks:
            try:
                task_scheduler._save_task_metadata(task_id)
            except Exception as persist_error:
                logger.warning(f"Could not persist schedule metadata for {task_id}: {persist_error}")

        task_scheduler.start()
        logger.info(f"Task scheduled: {task_id}")

    except Exception as e:
        handle_error(e, "Task scheduling")


@cli.command()
def schedule_interactive() -> None:
    """Launch the scheduling wizard (also offered during setup).

    Requires the user to be logged in before scheduling tasks.
    """
    if not require_login():
        return

    try:
        from Primary_Project_Code.scheduler import interactive_schedule
        interactive_schedule(task_scheduler)
    except Exception as e:
        handle_error(e, "Interactive scheduling")

@cli.command()
def start_scheduler() -> None:
    """Start the background task scheduler"""
    if not require_login():
        return
    try:
        task_scheduler.start()
        click.secho(" Scheduler started successfully!", fg='green')
        click.secho(" Tip: Scheduler runs in background. Press Ctrl+C to continue.", fg='cyan')
        
        # Keep the scheduler running
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            click.secho("\n  Scheduler stopped by user", fg='yellow')
    
    except Exception as e:
        handle_error(e, "Scheduler startup")


@cli.command()
def stop_scheduler() -> None:
    """Stop the background task scheduler"""
    if not require_login():
        return
    try:
        task_scheduler.stop()
        click.secho(" Scheduler stopped successfully!", fg='green')
        logger.info("Scheduler stopped via CLI")
    
    except Exception as e:
        handle_error(e, "Scheduler shutdown")

@cli.command()
def list_tasks() -> None:
    """List all scheduled tasks"""
    if not require_login():
        return
    try:
        tasks = task_scheduler.list_tasks()
        
        if not tasks:
            click.secho("❌ No tasks scheduled yet", fg='yellow')
            return
        
        click.secho("\n📋 Scheduled Tasks:", fg='cyan', bold=True)
        click.echo("-" * 50)
        
        for task_id, schedule_info in tasks.items():
            click.echo(f"  • {task_id}: {schedule_info}")
        
        click.echo("-" * 50)
        
        next_runs = task_scheduler.get_next_runs()
        if next_runs:
            click.secho("\n⏱️  Next Runs:", fg='cyan', bold=True)
            for run_info in next_runs:
                idle = run_info['idle_seconds']
                click.echo(f"  • Next run in: {idle:.0f} seconds")
    
    except Exception as e:
        handle_error(e, "Task listing")


@cli.command()
def remove_task() -> None:
    """Remove a scheduled task by ID"""
    if not require_login():
        return
    try:
        tasks = task_scheduler.list_tasks()
        
        if not tasks:
            click.secho("❌ No tasks scheduled yet", fg='yellow')
            return
        
        click.secho("\n📋 Available Tasks:", fg='cyan')
        task_ids = list(tasks.keys())
        
        for i, task_id in enumerate(task_ids, 1):
            click.echo(f"  {i}. {task_id} ({tasks[task_id]})")
        
        choice = click.prompt("Select task to remove (number)", type=int)
        
        if 1 <= choice <= len(task_ids):
            task_id = task_ids[choice - 1]
            if task_scheduler.remove_task(task_id):
                click.secho(f"✅ Task removed: {task_id}", fg='green')
                logger.info(f"Task removed: {task_id}")
            else:
                click.secho(f"❌ Failed to remove task: {task_id}", fg='red')
        else:
            click.secho("❌ Invalid selection", fg='red')
    
    except Exception as e:
        handle_error(e, "Task removal")

