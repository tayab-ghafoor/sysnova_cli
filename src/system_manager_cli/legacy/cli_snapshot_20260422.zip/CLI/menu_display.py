# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""
MenuDisplay - Menu Display Handler

SINGLE RESPONSIBILITY:
- Display menu options to user
- Return user's choice
- NO business logic
- NO input validation beyond format

ARCHITECTURE COMPLIANCE:
- Pure display functions
- Stateless
- Input collection only (validation happens in PromptCollector)
"""

from typing import Optional, Dict, Any


class MenuDisplay:
    """Display menus and collect menu selections"""
    
    @staticmethod
    def display_main_menu() -> Optional[Dict[str, Any]]:
        """
        Display main menu and get user selection
        
        Returns:
            Dict with "choice" key, or None if exit
        """
        print("\n" + "="*50)
        print("SYSTEM MANAGER CLI")
        print("="*50)
        print("\n1. Analyze Logs")
        print("2. Backup System")
        print("3. Health Check")
        print("4. Authentication")
        print("0. Exit")
        print()
        
        choice = input("Enter your choice (0-4): ").strip()
        
        if choice in ["0", "1", "2", "3", "4"]:
            return {"choice": choice}
        
        print("Invalid choice. Please try again.")
        return None
    
    @staticmethod
    def display_backup_type_menu() -> Optional[str]:
        """
        Display backup type options
        
        Returns:
            Selected backup type or None
        """
        print("\n--- Backup Type ---")
        print("1. Full Backup (complete copy)")
        print("2. Incremental (only changes since last backup)")
        print("3. Differential (changes since last full backup)")
        print()
        
        choice = input("Select backup type (1-3): ").strip()
        
        if choice == "1":
            return "full"
        elif choice == "2":
            return "incremental"
        elif choice == "3":
            return "differential"
        else:
            print("Invalid choice.")
            return None
    
    @staticmethod
    def display_confirmation(message: str) -> bool:
        """
        Display confirmation prompt
        
        Args:
            message: Confirmation message
            
        Returns:
            True if user confirms, False otherwise
        """
        response = input(f"\n{message} (y/n): ").strip().lower()
        return response in ["y", "yes"]
    
    @staticmethod
    def display_success(message: str) -> None:
        """Display success message"""
        print(f"\n✅ {message}")
    
    @staticmethod
    def display_error(message: str) -> None:
        """Display error message"""
        print(f"\n❌ {message}")
    
    @staticmethod
    def display_info(message: str) -> None:
        """Display info message"""
        print(f"\nℹ️ {message}")
