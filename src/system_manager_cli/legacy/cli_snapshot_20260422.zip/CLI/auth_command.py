# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.





@click.group()
def cli():
    """System Manager CLI - Your go-to tool for system management"""
    pass


def _offer_schedule_after_registration(email: str, password: str) -> None:
    """Optionally log in the new user and launch the scheduling wizard."""
    if not click.confirm("Do you want to login now and schedule a backup/task?", default=True):
        return

    login_result = auth_manager.login(email, password)
    if not login_result.get('success'):
        click.secho(
            "Registration succeeded, but auto-login failed. Please login and schedule manually.",
            fg='yellow'
        )
        logger.warning(
            f"Auto-login failed after registration for {email}: {login_result.get('message')}"
        )
        return

    current_user['email'] = login_result.get('email')
    current_user['name'] = login_result.get('name')
    current_user['token'] = login_result.get('token')
    click.secho(f"Logged in as {current_user['name']}", fg='green')

    from Primary_Project_Code.scheduler import interactive_schedule
    interactive_schedule(task_scheduler)


@cli.command()
def register():
    """Register a new user account"""
    click.secho("\n" + "="*50, fg='cyan')
    click.secho("📝 User Registration", fg='cyan')
    click.secho("="*50 + "\n", fg='cyan')
    
    email = click.prompt('📧 Enter your email')
    full_name = click.prompt('👤 Enter your full name (optional)', default='')
    
    while True:
        password = click.prompt('🔐 Enter password (min 8 chars, 1 uppercase, 1 digit)', hide_input=False)
        confirm_password = click.prompt('🔐 Confirm password')
        
        if password != confirm_password:
            click.secho("❌ Passwords don't match. Try again.", fg='red')
            continue
        break
    
    result = auth_manager.register_user(email, password, full_name)
    
    if result['success']:
        click.secho(f"\n✅ {result['message']}", fg='green')
        click.secho(f"You can now login with: {email}\n", fg='green')
        logger.info(f"New user registered: {email}")
        _offer_schedule_after_registration(email, password)
    else:
        click.secho(f"\n❌ {result['message']}", fg='red')
        logger.warning(f"Registration failed for {email}: {result['message']}")
@cli.command()
def login():
    """Login to your account"""
    click.secho("\n" + "="*50, fg='cyan')
    click.secho("🔐 User Login", fg='cyan')
    click.secho("="*50 + "\n", fg='cyan')
    
    result = _prompt_login_with_reset()
    
    if result['success']:
        _complete_login(result)
        click.secho(f"\n✅ Welcome {result['name']}!", fg='green')
        click.secho(f"You are now logged in.\n", fg='green')
        logger.info(f"User logged in: {result['email']}")
        
        # Show menu after login
        click.pause()
        interactive_menu()


@cli.command()
def logout():
    """Logout from your account"""
    if not is_user_logged_in():
        click.secho("❌ You are not logged in.", fg='red')
        return
    
    email = current_user['email']
    if email:
        result = auth_manager.logout(email)
        
        if result['success']:
            current_user['email'] = None
            current_user['name'] = None
            current_user['token'] = None
            click.secho("✅ Logged out successfully!", fg='green')
            logger.info(f"User logged out: {email}")
        else:
            click.secho(f"❌ {result['message']}", fg='red')


@cli.command(name='reset-password')
def reset_password() -> None:
    """Reset your password using an emailed reset code."""
    click.secho("\n" + "="*50, fg='cyan')
    click.secho("Password Reset", fg='cyan')
    click.secho("="*50 + "\n", fg='cyan')
    _run_password_reset_flow()


@cli.command()
@click.option('--current', is_flag=True, help='Show current password (verify it)')
def change_password(current):
    """Change your password"""
    if not is_user_logged_in():
        click.secho("❌ You must login first!", fg='red')
        return
    
    email = current_user['email']
    if not email:
        click.secho("❌ User email not found!", fg='red')
        return
    
    if current:
        # Verify current password
        password = click.prompt('🔐 Enter your current password', hide_input=True)
        user = auth_manager.users.get(email)
        if user and not auth_manager.verify_password(password, user['password_hash']):
            click.secho("❌ Current password is incorrect.", fg='red')
            return
    
    while True:
        new_password = click.prompt('🔐 Enter new password (min 8 chars, 1 uppercase, 1 digit)', hide_input=True)
        confirm_password = click.prompt('🔐 Confirm new password', hide_input=True)
        
        if new_password != confirm_password:
            click.secho("❌ Passwords don't match. Try again.", fg='red')
            continue
        break
    
    old_password = click.prompt('🔐 Enter your current password to confirm', hide_input=True)
    result = auth_manager.change_password(email, old_password, new_password)
    
    if result['success']:
        click.secho(f"✅ {result['message']}", fg='green')
        logger.info(f"Password changed for user: {email}")
    else:
        click.secho(f"❌ {result['message']}", fg='red')


@cli.command()
def show_profile():
    """Show your profile information"""
    if not is_user_logged_in():
        click.secho("❌ You must login first!", fg='red')
        return
    
    email = current_user['email']
    user = auth_manager.users.get(email)
    
    if user:
        click.secho("\n" + "="*50, fg='cyan')
        click.secho("👤 Your Profile", fg='cyan')
        click.secho("="*50 + "\n", fg='cyan')
        click.secho(f"Email: {user['email']}")
        click.secho(f"Name: {user.get('full_name', 'N/A')}")
        click.secho(f"Created: {user.get('created_at', 'N/A')}")
        click.secho(f"Last Login: {user.get('last_login', 'Never')}\n")
        logger.info(f"Profile viewed by: {email}")
    else:
        click.secho("❌ User not found.", fg='red')


@cli.command()
@click.option('--email', is_flag=True, help='Send email alerts if issues found')