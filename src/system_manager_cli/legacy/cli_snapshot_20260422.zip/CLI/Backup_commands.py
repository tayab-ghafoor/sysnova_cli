# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
import click
from pathlib import Path
from typing import Optional, Callable, Any, cast, List, Dict
from config.config import Config
from core.Backup_manager import BackupManager, validate_backup_drive, _calculate_backup_item_size
from core.Auth import is_user_logged_in, current_user
from core.scheduler import _has_internet

@cli.command()
@click.argument('sources', nargs=-1, type=click.Path(exists=True))
@click.option('--backup-drive', type=click.Path(exists=True), help='Backup drive path', default=None)
@click.option('--format', type=click.Choice(['zip', 'folder', 'auto'], case_sensitive=False), default='auto', help='Backup format: zip, folder, or auto (ask)')
@click.option('--list', 'list_backups', is_flag=True, help='List existing backups')
def backup_folder(sources: tuple[str, ...], backup_drive: Optional[str], format: str, list_backups: bool) -> None:
    """
    Backup important files or folders
    
    SOURCES: One or more file/folder paths to backup
    
    Features:
    - Backup a single file, a single folder, or multiple files/folders
    - Automatically detects whether each path is a file or a folder
    - Choose between ZIP (compressed) or folder (browse-able) format
    - Keeps only the last 7 backups
    - Logs all operations
    """
    try:
        _run_backup_operation(sources, backup_drive, format, list_backups)
        return
        # Validate source (file or directory)
        source_path = validate_path_exists(source, path_type="any")
        validate_path_readable(source_path)
        
        # Validate backup drive
        if backup_drive:
            backup_dest = validate_path_exists(backup_drive, path_type="directory")
            validate_path_writable(backup_dest)
        else:
            validate_backup_drive()
        
        if list_backups:
            try:
                backup_mgr = BackupManager(source, backup_drive)
                backup_mgr.list_backups()
                return
            except Exception as e:
                handle_error(e, "List backups")
                return
        
        # Calculate required disk space
        if source_path.is_file():
            item_size = source_path.stat().st_size
            is_file = True
        else:
            item_size = get_folder_size(source_path)
            is_file = False
        
        required_space = item_size * 1.5
        backup_path = Path(backup_drive or Config.BACKUP_DRIVE)
        
        try:
            validate_disk_space(backup_path, int(required_space))
        except DiskSpaceError as e:
            handle_error(e, "Backup validation")
            return
        
        # Determine backup format
        use_zip = None
        if format.lower() == 'auto':
            click.echo(f"\n📦 Backing up: {source}")
            click.echo(f"   Size: {item_size / (1024**2):.2f} MB")
            click.echo("\n💾 Choose backup format:")
            click.echo("   [1] ZIP (compressed, smaller size, need to extract to view)")
            click.echo("   [2] Folder (uncompressed, browse files directly on Drive)\n")
            choice = click.prompt("Select format", type=click.Choice(['1', '2']), default='1')
            use_zip = (choice == '1')
        else:
            use_zip = (format.lower() == 'zip')
        
        format_name = "ZIP" if use_zip else "Folder"
        click.echo(f"\n📦 Starting backup ({format_name} format): {source}")
        click.echo(f"   Size: {item_size / (1024**2):.2f} MB")
        
        backup_mgr = BackupManager(source, backup_drive)
        backup_path = backup_mgr.create_backup(compress=use_zip)
        backup_mgr.display_backup_status(backup_path)
        
        if backup_path:
            logger.info(f"Backup created successfully: {backup_path}")
            click.secho("✅ Backup completed!", fg='green')

            # send email if user is logged in and has an email
            if is_user_logged_in():
                user_email = current_user.get('email')
                if user_email:
                    try:
                        backup_mgr.send_backup_email(user_email, backup_path, "Manual")
                    except Exception as e:
                        logger.error(f"Failed to send backup email: {e}")
        else:
            click.secho("❌ Backup failed - no backup path returned", fg='red')
    
    except PathError as e:
        handle_error(e, "Backup operation")
    except PermissionError as e:
        handle_error(e, "Backup operation")
    except DiskSpaceError as e:
        handle_error(e, "Backup operation")
    except BackupError as e:
        handle_error(e, "Backup operation")
    except Exception as e:
        handle_error(e, "Backup operation")
        
        
@cli.command()
@click.argument('backup_path', type=click.Path(exists=True))
@click.option('--remote', default='gdrive', help='Rclone remote name (gdrive, onedrive, dropbox, etc.)')
@click.option('--remote-path', default='/System Backups', help='Path on remote to upload to')
@click.option('--list-remotes', is_flag=True, help='List available Rclone remotes')
def upload_backup_cloud(backup_path: str, remote: str, remote_path: str, list_remotes: bool) -> None:
    """
    Upload a backup to cloud storage using Rclone.
    If targeting Google Drive (remote named `gdrive`), the user will be asked
    to confirm the email address to associate with the Drive upload; an
    alternate address may be entered.
    
    BACKUP_PATH: Path to the backup file or folder
    
    Features:
    - Upload to Google Drive, OneDrive, Dropbox, S3, and more
    - Requires Rclone to be installed and configured
    - Supports multiple cloud remotes
    
    Examples:
      upload-backup-cloud /path/to/backup.zip --remote gdrive
      upload-backup-cloud /path/to/backup --remote onedrive --remote-path /MyBackups
    """
    if not is_user_logged_in():
        click.secho("❌ You must login first!", fg='red')
        return
    
    try:
        # Show available remotes if requested
        if list_remotes:
            from Primary_Project_Code.rclone_manager import rclone_manager
            click.secho("\n📋 Available Rclone Remotes:", fg='cyan', bold=True)
            click.echo("-" * 50)
            remotes = rclone_manager.list_remotes()
            if remotes:
                for r in remotes:
                    click.echo(f"  • {r}")
                click.echo("-" * 50 + "\n")
            else:
                click.secho("No remotes configured. Run 'rclone config' to set up.\n", fg='yellow')
            return
        
        # Validate backup path
        backup_file = validate_path_exists(backup_path, path_type="any")
        validate_path_readable(backup_file)
        
        click.echo(f"📦 Preparing to upload backup: {backup_path}")
        click.echo(f"   Remote: {remote}")
        click.echo(f"   Remote path: {remote_path}")

        # if using Google Drive remote, confirm email to use
        chosen_email = None
        if 'gdrive' in remote.lower():
            current_email = current_user.get('email', '')
            if current_email:
                confirm = click.confirm(
                    f"Do you want to backup data on this email ({current_email})?",
                    default=True
                )
                if confirm:
                    chosen_email = current_email
                else:
                    chosen_email = click.prompt(
                        "Enter alternative email to use for Drive backup",
                        default=current_email
                    )
            else:
                # not logged in? Shouldn't happen because require login earlier
                chosen_email = click.prompt("Enter email to use for Drive backup")
            click.echo(f"Using email for Drive backup: {chosen_email}\n")
            logger.info(f"Drive backup email selected: {chosen_email}")

        backup_mgr = BackupManager(".")  # Dummy source folder
        
        click.echo(f"\n🔄 Uploading backup to '{remote}'...")
        progress_cb = make_click_progress_callback(f"Uploading to {remote}")
        success = backup_mgr.upload_to_rclone(
            backup_file,
            remote,
            remote_path,
            progress_callback=progress_cb
        )
        
        if success:
            success_msg = "✅ Backup uploaded successfully!"
            if chosen_email:
                success_msg += f" (Drive email: {chosen_email})"
            click.secho(success_msg, fg='green')
            click.secho(f"📍 Location: {remote}:{remote_path}\n", fg='green')
            logger.info(f"Backup uploaded to {remote} email={chosen_email}")
        else:
            click.secho("❌ Upload failed", fg='red')
            click.secho("💡 Make sure Rclone is installed and the remote is configured.\n", fg='yellow')
            logger.warning(f"Failed to upload backup to {remote}")
    
    except PathError as e:
        handle_error(e, "Backup upload", f"Path: {backup_path}")
    except Exception as e:
        handle_error(e, "Backup upload")

