# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
import click
import asyncio
from system_manager_cli.CLI.auth_command import cli
from system_manager_cli.config.config import Config
from system_manager_cli.Analysis.Notifier import notify_new_report_available
from system_manager_cli.app import handle_error, ConfigurationError
from system_manager_cli.CLI.auth_command import cli
from core.scheduler import task_scheduler, async_health_check, run_async_tasks
from core.Auth import require_login
from ..core.File_organizer import FileOrganizer
from ..core.validator import validate_path_exists, validate_path_readable, validate_path_writable, validate_folder_not_empty
from ..core.Exception import PathError, FileOrganizationError
from ..ulits.logger import get_logger



@cli.command()
def setup() -> None:
    """Setup the CLI tool configuration"""
    click.echo("🔧 Setting up System Manager CLI...")
    
    Config.ensure_directories()
    
    click.echo("\nDirectories created/verified:")
    click.echo(f"  • Logs: {Config.LOGS_DIR}")
    click.echo(f"  • Reports: {Config.REPORTS_DIR}")
    
    click.echo("\n⚠️  Important: Configure your email settings in .env file for alerts:")
    click.echo("  EMAIL_SENDER=your_email@gmail.com")
    click.echo("  EMAIL_PASSWORD=your_app_password")
    click.echo("  EMAIL_RECIPIENT=recipient@gmail.com")

    # scheduling guidance
    click.secho("\n🕘 Task Scheduling", fg='cyan')
    click.echo("You may schedule recurring operations using the built-in wizard.")
    click.echo("This works much like setting an alarm on your phone – pick an")
    click.echo("operation (backup, health check, cleanup, or report), specify the")
    click.echo("time it should run, and choose a recurrence (daily, weekly, monthly).")
    click.echo("To schedule a task now, answer 'yes' to the prompt below.")
    if click.confirm("Do you want to schedule a task now?", default=False):
        if not require_login():
            click.echo("\n✅ Setup completed! But login is required to schedule tasks.")
        else:
            from Primary_Project_Code.scheduler import interactive_schedule
            interactive_schedule(task_scheduler)

    click.echo("\n✅ Setup completed!")


@cli.command()
@click.option('--monitor', is_flag=True, default=False, help='Monitor task execution')
def run_async_demo(monitor: bool) -> None:
    """
    Run async demo - execute multiple tasks concurrently
    
    Demonstrates async/await capabilities for parallel operations
    """
    try:
        click.secho("🚀 Running async task demo...", fg='cyan')
        
        # Create async tasks
        health_task = async_health_check()
        
        # Run multiple health checks concurrently
        results = asyncio.run(run_async_tasks(health_task, health_task, health_task))
        
        click.secho("✅ Async demo completed!", fg='green')
        click.echo(f"\n📊 Results: Ran 3 concurrent health checks")
        
        if results[0]:
            result = results[0]
            click.echo(f"  • CPU Usage: {result.get('cpu', 'N/A')}%")
            click.echo(f"  • RAM Usage: {result.get('memory', 'N/A')}%")
            click.echo(f"  • Disk Usage: {result.get('disk', 'N/A')}%")
        
        logger.info("Async demo completed successfully")
    
    except Exception as e:
        handle_error(e, "Async demo execution")


@cli.command()
@click.argument('folder_path', type=click.Path(exists=True))
@click.option('--rename', is_flag=True, default=True, help='Clean and rename files')
@click.option('--delete-duplicates', is_flag=True, default=True, help='Delete duplicate files')
@click.option('--report', is_flag=True, default=True, help='Generate report file')
@click.option('--dry-run', is_flag=True, help='Preview changes without executing')
def organize_files(folder_path: str, rename: bool, delete_duplicates: bool, report: bool, dry_run: bool) -> None:
    """
    Clean and organize a temporary folder

    FOLDER_PATH: Path to the folder to organize

    Features:
    - Organizes files by type (Images, Documents, Videos, etc.)
    - Renames files in a clean format
    - Detects and deletes duplicate files
    - Generates a report file
    """
    try:
        # Validate path
        folder = validate_path_exists(folder_path, path_type="directory")
        validate_path_readable(folder)
        validate_path_writable(folder)

        # Check if folder has files
        validate_folder_not_empty(folder)

        if dry_run:
            click.secho(f"🔍 DRY RUN MODE - No changes will be made", fg='cyan')

        click.echo(f"🔄 Organizing files in: {folder_path}")

        organizer = FileOrganizer(folder_path)

        if organizer.organize_files(rename=rename, delete_dups=delete_duplicates):
            organizer.display_summary()

            if report:
                organizer.generate_report()

            logger.info("File organization completed successfully")
            click.secho("✅ File organization completed!", fg='green')
        else:
            click.secho("❌ File organization failed - no files were processed", fg='red')
            logger.warning(f"File organization incomplete for: {folder_path}")

    except PathError as e:
        handle_error(e, "File organization", f"Path: {folder_path}")
    except PermissionError as e:
        handle_error(e, "File organization", f"Path: {folder_path}")
    except FileOrganizationError as e:
        handle_error(e, "File organization")
    except Exception as e:
        handle_error(e, "File organization", f"Path: {folder_path}")
