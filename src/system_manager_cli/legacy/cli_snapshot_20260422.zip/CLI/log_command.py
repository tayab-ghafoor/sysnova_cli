# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
import argparse
import click
import sys
from system_manager_cli.CLI.auth_command import is_user_logged_in
from src.system_manager_cli.Analysis.LogAnalyzer import analyze_logs
from src.system_manager_cli.Analysis.LogStreamer import stream_logs_from_path
from src.system_manager_cli.Analysis.ReportPrinter import print_analysis_report



def handle_logs_cli_mode(args: argparse.Namespace) -> None:
    """
    Handle CLI mode for log commands.
    
    Routes:
    - main.py logs analyze --cwd
    - main.py logs analyze /path/to/logs
    - main.py logs stream --cwd
    - main.py logs stream /path/to/logs
    """
    if not analyze_logs or not stream_logs_from_path:
        click.secho("❌ Error: Log analysis module not available", fg='red')
        sys.exit(1)

    if not is_user_logged_in():
        click.secho("❌ You must be logged in to use log analysis commands. Run the login command first.", fg='red')
        sys.exit(1)
    
    try:
        if args.subcommand == 'analyze':
            result = analyze_logs(
                path_str=args.path or '',
                use_cwd=args.cwd
            )
            if result:
                print_analysis_report(result)
        
        elif args.subcommand == 'stream':
            stream_logs_from_path(
                path_str=args.path or '',
                use_cwd=args.cwd
            )
    
    except ValueError as e:
        click.secho(f"❌ Error: {e}", fg='red')
        sys.exit(1)
    except KeyboardInterrupt:
        click.secho("\n✅ Command interrupted by user", fg='yellow')
        sys.exit(0)
    except Exception as e:
        click.secho(f"❌ Unexpected error: {e}", fg='red')
        sys.exit(1)

