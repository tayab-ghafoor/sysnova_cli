# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""
Core scheduler implementation extracted from the original scheduler.py.
This module contains the `TaskScheduler`, `AsyncTaskRunner` helpers and
convenience wrappers. It is intended to be imported by a facade module
(`scheduler.py`) to preserve backward compatibility.
"""
import sys
import importlib
from pathlib import Path
from typing import Callable, Dict, Any
from datetime import datetime

try:
    sys.modules['string'] = importlib.import_module('string')
except ImportError:
    pass

from .logger import get_logger
from .email_notifier import EmailNotifier

import schedule
import threading
import time
import asyncio
import json

logger = get_logger(__name__)


def _resolve_main_module():
    runtime_main = sys.modules.get("__main__")
    if runtime_main and getattr(runtime_main, "__file__", "").endswith("main.py"):
        return runtime_main

    for name in ("main", "system_manager_cli.main"):
        mod = sys.modules.get(name)
        if mod is not None:
            return mod
    return None


class TaskScheduler:
    """Manages scheduled tasks and background operations"""

    def __init__(self):
        self.scheduler = schedule.Scheduler()
        self.is_running = False
        self.worker_thread = None
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self._data_file = Path(__file__).parent / 'data' / 'scheduled_tasks.json'
        self._data_file.parent.mkdir(exist_ok=True)
        try:
            self._load_saved_tasks()
        except Exception:
            logger.debug("No saved scheduled tasks found or failed to load")

    def add_task(self, task_id: str, task_func: Callable, interval: int = 1, unit: str = 'seconds', *,
                 at_time: str | None = None, weekday: str | None = None, day_of_month: int | None = None) -> None:
        valid_units = ['seconds', 'minutes', 'hours', 'days', 'weeks']
        if unit not in valid_units:
            raise ValueError(f"Invalid unit. Must be one of: {valid_units}")

        job = getattr(self.scheduler.every(interval), unit)

        if weekday:
            if weekday.lower() not in (
                'monday', 'tuesday', 'wednesday', 'thursday',
                'friday', 'saturday', 'sunday'
            ):
                raise ValueError("""Invalid weekday. Must be one of monday–sunday""")
            job = getattr(self.scheduler.every(), weekday.lower())

        if at_time:
            job = job.at(at_time)

        def _run_in_thread():
            try:
                threading.Thread(target=task_func, daemon=True).start()
            except Exception as e:
                logger.error(f"Failed to start task thread: {e}")

        if day_of_month is not None:
            def _wrapper():
                if datetime.now().day == day_of_month:
                    return _run_in_thread()
            job = job.do(_wrapper)
        else:
            job = job.do(_run_in_thread)

        self.tasks[task_id] = {
            'job': job,
            'interval': interval,
            'unit': unit,
            'func': task_func,
            'at_time': at_time,
            'weekday': weekday,
            'day_of_month': day_of_month,
        }
        try:
            self._save_task_metadata(task_id)
        except Exception as e:
            logger.debug(f"Could not persist task metadata: {e}")
        logger.info(f"Task scheduled: {task_id} (every {interval} {unit}" + (f" at {at_time}" if at_time else "") + ")")

    def remove_task(self, task_id: str) -> bool:
        if task_id in self.tasks:
            self.scheduler.cancel_job(self.tasks[task_id]['job'])
            del self.tasks[task_id]
            self._save_all_tasks()
            logger.info(f"task removed: {task_id}")
            return True
        logger.warning(f"Task not found: {task_id}")
        return False

    def start(self) -> None:
        if not self.is_running:
            self.is_running = True
            self.worker_thread = threading.Thread(target=self._run_scheduler, daemon=True)
            self.worker_thread.start()
            logger.info("Scheduler started")

    def stop(self) -> None:
        self.is_running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        logger.info("Scheduler stopped")

    def _run_scheduler(self) -> None:
        while self.is_running:
            try:
                self.scheduler.run_pending()
                time.sleep(1)
            except Exception as e:
                logger.error(f"Scheduler error: {e}")

    def _save_all_tasks(self) -> None:
        try:
            data = {}
            for tid, info in self.tasks.items():
                entry = {
                    'interval': info.get('interval'),
                    'unit': info.get('unit'),
                    'at_time': info.get('at_time'),
                    'weekday': info.get('weekday'),
                    'day_of_month': info.get('day_of_month'),
                }
                if info.get('action_name'):
                    entry['action_name'] = info.get('action_name')
                    entry['action_args'] = info.get('action_args', [])
                    entry['action_kwargs'] = info.get('action_kwargs', {})
                    if info.get('user_email'):
                        entry['user_email'] = info.get('user_email')
                else:
                    entry['func_name'] = getattr(info.get('func'), '__name__', None)
                data[tid] = entry
            with open(self._data_file, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save scheduled tasks: {e}")

    def _save_task_metadata(self, task_id: str) -> None:
        self._save_all_tasks()

    def _load_saved_tasks(self) -> None:
        if not self._data_file.exists():
            return
        try:
            with open(self._data_file, 'r') as f:
                saved = json.load(f)
        except Exception as e:
            logger.error(f"Failed to read saved scheduled tasks: {e}")
            return

        for tid, meta in saved.items():
            try:
                def _resolve_action(action_name: str):
                    mod = _resolve_main_module()
                    if mod and hasattr(mod, action_name):
                        return getattr(mod, action_name)
                    return None

                if meta.get('action_name'):
                    action_name = meta.get('action_name')
                    action_args = meta.get('action_args', [])
                    action_kwargs = meta.get('action_kwargs', {})
                    resolved_func = _resolve_action(action_name)

                    def _make_wrapper(f, a, kw, task_identifier, action_identifier):
                        def _wrapper():
                            try:
                                if f is not None:
                                    return f(*a, **kw)
                                lazy_func = _resolve_action(action_identifier)
                                if lazy_func is None:
                                    raise RuntimeError(f"Action '{action_identifier}' is not available")
                                return lazy_func(*a, **kw)
                            except Exception as e:
                                logger.error(f"Scheduled task {task_identifier} failed: {e}")
                        return _wrapper

                    wrapper = _make_wrapper(resolved_func, action_args, action_kwargs, tid, action_name)
                    self.add_task(tid, wrapper, interval=meta.get('interval', 1), unit=meta.get('unit', 'days'), at_time=meta.get('at_time'), weekday=meta.get('weekday'), day_of_month=meta.get('day_of_month'))
                    user_email = meta.get('user_email')
                    if not user_email:
                        try:
                            from .config import Config
                            user_email = Config.EMAIL_RECIPIENT
                        except Exception:
                            user_email = None
                    if meta.get('at_time') and user_email:
                        try:
                            hh, mm = map(int, meta.get('at_time').split(':'))
                            scheduled_dt = datetime.now().replace(hour=hh, minute=mm, second=0, microsecond=0)
                            if scheduled_dt < datetime.now():
                                subj = 'Scheduled Task Missed - Please Open Application'
                                body = f"A scheduled task ('{action_name}') was set for {meta.get('at_time')} but the application was not running. Please open the System Manager CLI to allow the task to run."
                                try:
                                    EmailNotifier._send_email(user_email, subj, body)
                                except Exception:
                                    logger.debug("Could not send missed-task reminder email")
                        except Exception:
                            pass
                    self.tasks[tid]['action_name'] = action_name
                    self.tasks[tid]['action_args'] = action_args
                    self.tasks[tid]['action_kwargs'] = action_kwargs
                    try:
                        self._save_task_metadata(tid)
                    except Exception:
                        logger.debug("Could not refresh restored task metadata")
                    logger.info(f"Restored scheduled task: {tid} (action: {action_name})")
                else:
                    func_name = meta.get('func_name')
                    main_mod = _resolve_main_module()
                    func = getattr(main_mod, func_name) if main_mod and func_name and hasattr(main_mod, func_name) else None
                    if func is None:
                        logger.debug(f"Skipping restore for task {tid}: function {func_name} unavailable")
                        continue
                    self.add_task(tid, func, interval=meta.get('interval', 1), unit=meta.get('unit', 'days'), at_time=meta.get('at_time'), weekday=meta.get('weekday'), day_of_month=meta.get('day_of_month'))
                    logger.info(f"Restored scheduled task: {tid}")
            except Exception as e:
                logger.error(f"Failed to restore task {tid}: {e}")

    def send_task_completion_email(self, task_id: str, user_email: str, task_description: str = "", status: str = "SUCCESS") -> bool:
        try:
            task_info = self.tasks.get(task_id, {})
            if not task_info:
                logger.warning(f"Task {task_id} not found for email notification; using fallback schedule text")
                schedule_time = "Configured schedule"
            else:
                schedule_time = f"Every {task_info['interval']} {task_info['unit']}"
                if task_info.get('at_time'):
                    schedule_time += f" at {task_info['at_time']}"
                if task_info.get('weekday'):
                    schedule_time = f"Every {task_info['weekday']}"

            execution_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            return EmailNotifier.send_task_completion_email(user_email, task_id, task_description, schedule_time, execution_time, status)
        except Exception as e:
            logger.error(f"Failed to send task completion email: {e}")
            return False

    def list_tasks(self) -> Dict[str, str]:
        output: Dict[str, str] = {}
        for task_id, data in self.tasks.items():
            parts = [f"every {data['interval']} {data['unit']}" ]
            if data.get('at_time'):
                parts.append(f"at {data['at_time']}")
            if data.get('weekday'):
                parts.append(f"on {data['weekday']}")
            if data.get('day_of_month') is not None:
                parts.append(f"(day {data['day_of_month']})")
            output[task_id] = " ".join(parts)
        return output

    def get_next_runs(self) -> list:
        next_runs = []
        import datetime as _dt
        for job in self.scheduler.jobs:
            next_run = getattr(job, 'next_run', None)
            idle = None
            if next_run:
                delta = next_run - _dt.datetime.now()
                idle = int(delta.total_seconds()) if delta.total_seconds() > 0 else 0
            next_runs.append({'job': job, 'next_run': next_run, 'idle_seconds': idle})
        return next_runs

    def clear_all(self) -> None:
        self.scheduler.clear()
        self.tasks.clear()
        logger.info("All scheduled tasks cleared")


class AsyncTaskRunner:
    @staticmethod
    async def run_concurrent(*coros):
        return await asyncio.gather(*coros)

    @staticmethod
    def run_async(coro):
        return asyncio.run(coro)


def schedule_task(task_id: str, task_func: Callable, interval: int, unit: str = 'seconds', *, at_time: str | None = None, weekday: str | None = None, day_of_month: int | None = None) -> None:
    scheduler = TaskScheduler()
    scheduler.add_task(task_id, task_func, interval, unit, at_time=at_time, weekday=weekday, day_of_month=day_of_month)


def create_task_wrapper(func: Callable, *args, **kwargs) -> Callable:
    def wrapper():
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
    return wrapper
