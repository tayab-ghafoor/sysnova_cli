# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
"""Compatibility facade for the scheduler package.

This module keeps the original module path (`Primary_Project_Code.scheduler`)
but delegates implementation to two smaller modules:

- `scheduler_core` contains `TaskScheduler`, `AsyncTaskRunner` and helpers
- `scheduler_cli` contains interactive CLI helper functions

Importing from this module preserves the original public API while making
the implementation easier to maintain.
"""

from .scheduler_core import (
    TaskScheduler,
    AsyncTaskRunner,
    schedule_task,
    create_task_wrapper,
    _resolve_main_module,
)

from .scheduler_cli import (
    interactive_remove_task,
    interactive_schedule,
    interactive_edit_task,
    view_tasks,
    scheduler_menu,
)

__all__ = [
    'TaskScheduler',
    'AsyncTaskRunner',
    'schedule_task',
    'create_task_wrapper',
    'interactive_remove_task',
    'interactive_schedule',
    'interactive_edit_task',
    'view_tasks',
    'scheduler_menu',
]



from Primary_Project_Code.scheduler import TaskScheduler

# global scheduler instance used throughout the CLI
task_scheduler = TaskScheduler()
# start scheduler loop as soon as CLI starts so restored tasks can run
task_scheduler.start()

# ==================== ASYNC HELPER FUNCTIONS ====================

async def async_health_check():
    """Async version of health check"""
    try:
        monitor = HealthMonitor()
        results = monitor.check_system_health()
        logger.info(f"Async health check: CPU={results.get('cpu')}%, "
                   f"RAM={results.get('memory')}%, Disk={results.get('disk')}%")
        return results
    except Exception as e:
        logger.error(f"Async health check failed: {e}")
        return None


async def async_backup(source_folder: str):
    """Async version of backup operation"""
    try:
        backup_mgr = BackupManager(source_folder)
        backup_path = backup_mgr.create_backup(compress=True)
        logger.info(f"Async backup completed: {backup_path}")
        return backup_path
    except Exception as e:
        logger.error(f"Async backup failed: {e}")
        return None


async def run_async_tasks(*tasks):
    """Run multiple async tasks concurrently"""
    return await asyncio.gather(*tasks)


def scheduled_health_check(schedule_desc: str = ""):
    """Wrapper for scheduled health checks"""
    try:
        monitor = HealthMonitor()
        results = monitor.check_system_health()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logger.info(f"[{timestamp}] Scheduled health check - "
                   f"CPU: {results.get('cpu')}%, RAM: {results.get('memory')}%")

        # email notification for task completion
        if is_user_logged_in():
            user_email = current_user.get('email')
            if user_email:
                task_scheduler.send_task_completion_email(
                    task_id=schedule_desc or "health",
                    user_email=user_email,
                    task_description="System health check",
                    status="SUCCESS"
                )
    except Exception as e:
        logger.error(f"Scheduled health check failed: {e}")


def scheduled_backup(
    folder_path: str | list[str] | tuple[str, ...],
    schedule_desc: str = "",
    user_email: str | None = None,
    use_google_drive: bool = False,
    remote_name: str = "gdrive",
):
    """Wrapper for scheduled backup

    This wrapper will wait for internet connectivity if required, perform
    the backup, and notify the user via email even when they are not
    interactively logged in.
    """
    try:
        source_args = _coerce_backup_sources_arg(folder_path)
        source_paths = _prepare_backup_sources(source_args)
        sources_display = ", ".join(str(path) for path in source_paths)

        # helper to check internet connectivity
        import socket
        def _has_internet(timeout: float = 3.0) -> bool:
            try:
                socket.create_connection(("8.8.8.8", 53), timeout=timeout)
                return True
            except Exception:
                return False

        # if user_email was not provided, try to use currently logged-in user
        if not user_email and is_user_logged_in():
            user_email = current_user.get('email')
        # final fallback to configured default recipient
        if not user_email:
            user_email = Config.EMAIL_RECIPIENT

        validate_backup_drive()
        total_size = sum(_calculate_backup_item_size(source_path) for source_path in source_paths)
        validate_disk_space(Path(Config.BACKUP_DRIVE), int(total_size * 1.5))

        # Wait for connectivity only when cloud upload is requested.
        if use_google_drive and not _has_internet():
            logger.warning("No internet connectivity detected for scheduled cloud backup. Waiting until connection is restored...")
            wait_start = datetime.now()
            while not _has_internet():
                time.sleep(10)
            wait_end = datetime.now()
            logger.info(f"Internet restored after {int((wait_end-wait_start).total_seconds())}s; proceeding with cloud backup")

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        completed_backups = 0

        for source_path in source_paths:
            backup_mgr = BackupManager(str(source_path))
            backup_path = backup_mgr.create_backup(compress=True)
            logger.info(f"[{timestamp}] Scheduled backup completed: {backup_path}")

            if not backup_path:
                logger.error(f"Scheduled backup failed for {source_path}")
                continue

            completed_backups += 1

            if use_google_drive:
                progress_cb = make_click_progress_callback(
                    f"Scheduled cloud upload ({remote_name}) - {source_path.name}"
                )
                uploaded = backup_mgr.upload_to_rclone(
                    backup_path,
                    remote_name,
                    '/System Backups',
                    progress_callback=progress_cb
                )
                if uploaded:
                    logger.info(
                        f"Scheduled backup uploaded to Google Drive remote '{remote_name}': {backup_path}"
                    )
                else:
                    logger.error(
                        f"Scheduled backup upload to Google Drive remote '{remote_name}' failed for {backup_path}"
                    )

            if user_email:
                try:
                    backup_mgr.send_scheduled_backup_email(
                        user_email,
                        schedule_desc or "Scheduled Backup",
                        backup_path,
                        schedule_desc or ""
                    )
                except Exception as e:
                    logger.error(f"Failed to send scheduled backup email: {e}")

        # always send a generic task completion email for scheduled tasks
        if user_email:
            status = "SUCCESS" if completed_backups == len(source_paths) else "WARNING" if completed_backups else "FAILED"
            task_scheduler.send_task_completion_email(
                task_id=schedule_desc or "backup",
                user_email=user_email,
                task_description=f"Backup of {sources_display}",
                status=status
            )
    except Exception as e:
        logger.error(f"Scheduled backup failed: {e}")


def scheduled_cleanup(folder_path: str, schedule_desc: str = "", user_email: str | None = None):
    """Wrapper for scheduled cleanup

    Performs the cleanup and sends a task completion email to the
    specified user_email if provided (or the logged-in user).
    """
    try:
        if not user_email and is_user_logged_in():
            user_email = current_user.get('email')

        organizer = FileOrganizer(folder_path)
        organizer.organize_files(rename=True, delete_dups=True)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logger.info(f"[{timestamp}] Scheduled cleanup completed: {folder_path}")

        if user_email:
            task_scheduler.send_task_completion_email(
                task_id=schedule_desc or "cleanup",
                user_email=user_email,
                task_description=f"Cleanup of {folder_path}",
                status="SUCCESS"
            )
    except Exception as e:
        logger.error(f"Scheduled cleanup failed: {e}")


def scheduled_log_analysis(log_path: str, schedule_desc: str = ""):
    """Wrapper for scheduled log analysis"""
    try:
        path = Path(log_path)
        paths = [path] if path.exists() else []

        report_path = run_log_analysis(paths)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        logger.info(f"[{timestamp}] Scheduled log analysis completed")

        if is_user_logged_in():
            user_email = current_user.get('email')
            if user_email:
                task_scheduler.send_task_completion_email(
                    task_id=schedule_desc or "log_analysis",
                    user_email=user_email,
                    task_description=f"Log analysis on {log_path}",
                    status="SUCCESS"
                )

        if report_path and path.exists():
            logger.info(f"Scheduled log analysis report saved: {report_path}")
    except Exception as e:
        logger.error(f"Scheduled log analysis failed: {e}")


