# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
import time
"""
Interactive and CLI helpers for the scheduler.
Extracted from the original `scheduler.py` and designed to work with
`scheduler_core.TaskScheduler`.
"""
from pathlib import Path
from typing import Dict, Any
import click

from .scheduler_core import TaskScheduler, _resolve_main_module


def interactive_remove_task(scheduler: TaskScheduler) -> None:
    remove_choice = click.confirm("Do you want to remove scheduled tasks?", default=False)
    if not remove_choice:
        click.secho("Operation cancelled.", fg="yellow")
        return
    tasks = scheduler.list_tasks()
    if not tasks:
        click.secho("No Sheduled task found", fg="yellow")
        return
    click.secho("\n📋 Scheduled Tasks:", fg="cyan", bold=True)
    task_ids = list(tasks.keys())
    for index, task_id in enumerate(task_ids, start=1):
        click.secho(f"{index}. {task_id} - {tasks[task_id]}", fg="white")
    try:
        choice = click.prompt("\n Enter the number of the task to remove ", type=int)
    except Exception:
        click.secho("Invalid Input.", fg="red")
        return
    if choice < 1 or choice > len(task_ids):
        click.secho("Invalid Selection.", fg="red")
        return
    selected_task_id = task_ids[choice - 1]
    conform_delete = click.confirm(f"Are you sure you want to delete '{selected_task_id}'?", default=False)
    if not conform_delete:
        click.secho("Deletion Cancelled.", fg="yellow")
        return
    removed = scheduler.remove_task(selected_task_id)
    if removed:
        click.secho("Task removed successfully!", fg="green")
    else:
        click.secho("Failed to remove task.", fg="red")


def _build_schedule_description(frequency: str, time_str: str, weekday: str | None = None, day_of_month: int | None = None) -> str:
    if frequency == 'weekly' and weekday:
        return f"every {weekday} at {time_str}"
    if frequency == 'monthly' and day_of_month is not None:
        return f"day {day_of_month} of every month at {time_str}"
    return f"every day at {time_str}"


def _task_display_details(task_id: str, task_info: Dict[str, Any]) -> Dict[str, str]:
    action_name = task_info.get('action_name')
    raw_name = action_name or task_id.split('_')[0]
    name = raw_name.replace('scheduled_', '').replace('_', ' ').title()

    action_args = task_info.get('action_args', [])
    path_value = "N/A"
    if raw_name.endswith('backup') or raw_name == 'backup':
        if action_args:
            sources = action_args[0]
            if isinstance(sources, (list, tuple)):
                path_value = ", ".join(str(path) for path in sources) if sources else "N/A"
            else:
                path_value = str(sources)
    elif (raw_name.endswith('cleanup') or raw_name == 'cleanup') and action_args:
        path_value = str(action_args[0])
    elif (raw_name.endswith('log_analysis') or raw_name == 'report') and action_args:
        path_value = str(action_args[0])

    time_value = task_info.get('at_time') or "N/A"
    if task_info.get('weekday'):
        time_value = f"{task_info['weekday'].title()} {time_value}"
    elif task_info.get('day_of_month') is not None:
        time_value = f"Day {task_info['day_of_month']} {time_value}"

    return {'name': name, 'time': time_value, 'path': path_value}


def view_tasks(scheduler: TaskScheduler) -> None:
    if not scheduler.tasks:
        click.secho("No scheduled tasks found.", fg="yellow")
        return

    rows = []
    for index, task_id in enumerate(scheduler.tasks.keys(), start=1):
        details = _task_display_details(task_id, scheduler.tasks[task_id])
        rows.append([str(index), details['name'], details['time'], details['path']])

    headers = ["ID", "Name", "Time", "Path"]
    widths = [len(header) for header in headers]
    for row in rows:
        for idx, value in enumerate(row):
            widths[idx] = max(widths[idx], len(value))

    header_line = " | ".join(header.ljust(widths[idx]) for idx, header in enumerate(headers))
    separator = "-" * len(header_line)

    click.secho("\nScheduled Tasks", fg="cyan", bold=True)
    click.echo(header_line)
    click.echo(separator)
    for row in rows:
        click.echo(" | ".join(value.ljust(widths[idx]) for idx, value in enumerate(row)))


def interactive_edit_task(scheduler: TaskScheduler) -> None:
    if not scheduler.tasks:
        click.secho("No scheduled tasks found.", fg="yellow")
        return

    view_tasks(scheduler)
    task_ids = list(scheduler.tasks.keys())
    try:
        choice = click.prompt("\nEnter the ID of the task to edit", type=int)
    except Exception:
        click.secho("Invalid input.", fg="red")
        return
    if choice < 1 or choice > len(task_ids):
        click.secho("Invalid selection.", fg="red")
        return

    task_id = task_ids[choice - 1]
    task_info = scheduler.tasks[task_id]
    details = _task_display_details(task_id, task_info)
    click.secho(f"Editing task: {details['name']}", fg="cyan")

    frequency = click.prompt(
        "Select new frequency",
        type=click.Choice(['daily', 'weekly', 'monthly']),
        default='weekly' if task_info.get('weekday') else 'monthly' if task_info.get('day_of_month') is not None else 'daily'
    )
    time_str = click.prompt("Enter new time (HH:MM)", default=task_info.get('at_time') or "00:00")

    weekday = None
    day_of_month = None
    if frequency == 'weekly':
        weekday = click.prompt(
            "Select weekday",
            type=click.Choice(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']),
            default=(task_info.get('weekday') or 'monday')
        )
    elif frequency == 'monthly':
        default_day = task_info.get('day_of_month') if task_info.get('day_of_month') is not None else 1
        day_of_month = click.prompt("Enter day of month", type=int, default=default_day)

    if not click.confirm(f"Save changes to '{details['name']}'?", default=True):
        click.secho("Edit cancelled.", fg="yellow")
        return

    preserved = {
        'func': task_info['func'],
        'action_name': task_info.get('action_name'),
        'action_args': list(task_info.get('action_args', [])),
        'action_kwargs': dict(task_info.get('action_kwargs', {})),
        'user_email': task_info.get('user_email'),
    }

    interval = 7 if frequency == 'weekly' else 1
    scheduler.scheduler.cancel_job(task_info['job'])
    del scheduler.tasks[task_id]
    scheduler.add_task(task_id, preserved['func'], interval=interval, unit='days', at_time=time_str, weekday=weekday, day_of_month=day_of_month)

    updated_task = scheduler.tasks[task_id]
    if preserved['action_name']:
        updated_task['action_name'] = preserved['action_name']
    updated_task['action_kwargs'] = preserved['action_kwargs']
    if preserved['user_email']:
        updated_task['user_email'] = preserved['user_email']

    if preserved['action_args']:
        updated_args = preserved['action_args']
        if len(updated_args) > 1 and isinstance(updated_args[1], str):
            updated_args[1] = _build_schedule_description(frequency, time_str, weekday=weekday, day_of_month=day_of_month)
        updated_task['action_args'] = updated_args

    scheduler._save_task_metadata(task_id)
    click.secho("Task updated successfully!", fg="green")


def interactive_schedule(scheduler: TaskScheduler) -> None:
    main_mod = _resolve_main_module()
    if main_mod is None:
        try:
            import main as main_mod  # type: ignore
        except Exception:
            main_mod = None

    if main_mod is not None and hasattr(main_mod, 'is_user_logged_in'):
        if not getattr(main_mod, 'is_user_logged_in')():
            click.secho("❌ You must be logged in to schedule a task.", fg='red')
            return

    click.secho("\n📅 Schedule a task", fg='cyan', bold=True)
    choices = ['health', 'backup', 'cleanup', 'report']
    task = click.prompt("Which operation do you want to setup?", type=click.Choice(choices))

    folder = None
    backup_sources = None
    log_path = None
    if task == 'backup':
        raw_sources = click.prompt("Enter file/folder path(s) to backup (comma-separated for multiple)")
        backup_sources = [path.strip() for path in raw_sources.split(',') if path.strip()]
        if not backup_sources:
            click.secho("❌ At least one backup path is required", fg='red')
            return
        invalid_sources = [path for path in backup_sources if not Path(path).exists()]
        if invalid_sources:
            click.secho(f"❌ Invalid backup path(s): {', '.join(invalid_sources)}", fg='red')
            return
    elif task == 'cleanup':
        folder = click.prompt("Enter the folder path", type=click.Path(exists=True))
    elif task == 'report':
        log_path = click.prompt("Enter the log file or folder path", type=click.Path(exists=True))

    frequency = click.prompt("Do you want the task to run every day, weekly or monthly?", type=click.Choice(['daily', 'weekly', 'monthly']), default='daily')
    time_str = click.prompt("At what time? (HH:MM, 24‑hour format)", default="00:00")

    weekday = None
    day_of_month = None
    if frequency == 'weekly':
        weekday = click.prompt("Which day of the week?", type=click.Choice(['monday','tuesday','wednesday','thursday','friday','saturday','sunday']), default='monday')
    elif frequency == 'monthly':
        day_of_month = click.prompt("Which day of the month?", type=int, default=1)

    google_drive_choice = False

    if main_mod is None:
        try:
            import main as main_mod  # type: ignore
        except Exception:
            main_mod = None

    if task == 'health':
        action = getattr(main_mod, 'scheduled_health_check')
    elif task == 'backup':
        google_drive_choice = click.confirm("Do you want to backup data on Google drive? (Y/N)", default=False)
        scheduled_backup = getattr(main_mod, 'scheduled_backup')
        action = lambda sources=tuple(backup_sources or []), gd=google_drive_choice: scheduled_backup(list(sources), use_google_drive=gd)  # type: ignore
    elif task == 'cleanup':
        scheduled_cleanup = getattr(main_mod, 'scheduled_cleanup')
        action = lambda folder=folder: scheduled_cleanup(folder)  # type: ignore
    else:
        scheduled_log_analysis = getattr(main_mod, 'scheduled_log_analysis')
        action = lambda log_path=log_path: scheduled_log_analysis(log_path)  # type: ignore

    task_id = f"{task}_{frequency}_{int(time.time())}"
    interval = 7 if frequency == 'weekly' else 1
    scheduler.add_task(task_id, action, interval=interval, unit='days', at_time=time_str, weekday=weekday, day_of_month=day_of_month)

    try:
        import main as main_mod
        user_email = getattr(main_mod, 'current_user', {}).get('email') if hasattr(main_mod, 'current_user') else None
    except Exception:
        user_email = None
    if not user_email:
        try:
            from .config import Config
            user_email = Config.EMAIL_RECIPIENT
        except Exception:
            user_email = None

    schedule_desc = _build_schedule_description(frequency, time_str, weekday=weekday, day_of_month=day_of_month)

    if task_id in scheduler.tasks:
        action_name_map = {'health': 'scheduled_health_check', 'backup': 'scheduled_backup', 'cleanup': 'scheduled_cleanup', 'report': 'scheduled_log_analysis'}
        scheduler.tasks[task_id]['action_name'] = action_name_map[task]
        if task == 'backup':
            scheduler.tasks[task_id]['action_args'] = [backup_sources or [], schedule_desc, user_email, google_drive_choice]
        elif task == 'cleanup':
            scheduler.tasks[task_id]['action_args'] = [folder, schedule_desc, user_email]
        elif task == 'report':
            scheduler.tasks[task_id]['action_args'] = [log_path, schedule_desc]
        elif task == 'health':
            scheduler.tasks[task_id]['action_args'] = [schedule_desc]
        else:
            scheduler.tasks[task_id]['action_args'] = []
        scheduler.tasks[task_id]['action_kwargs'] = {}
        if user_email:
            scheduler.tasks[task_id]['user_email'] = user_email
        try:
            scheduler._save_task_metadata(task_id)
        except Exception:
            pass

    if task == 'backup':
        click.secho(f"✅ Scheduled '{task}' for {len(backup_sources or [])} item(s) ({frequency} at {time_str})", fg='green')
    else:
        click.secho(f"✅ Scheduled '{task}' ({frequency} at {time_str})", fg='green')
    scheduler.start()


def scheduler_menu(scheduler: TaskScheduler) -> None:
    try:
        from Primary_Project_Code.main import is_user_logged_in
        if not is_user_logged_in():
            click.secho("❌ You must be logged in to access the Scheduler Menu.", fg="red")
            return
    except Exception:
        pass

    while True:
        click.secho("\n sheduler Menu ", fg="cyan", bold=True)
        click.echo("1. shedule Task")
        click.echo("2. View Scheduled Tasks")
        click.echo("3. Edit Scheduled Tasks")
        click.echo("4. Remove task")
        click.echo("5. Back")
        choice = click.prompt(" select an option (1-5)", type=int)
        if choice == 1 :
            interactive_schedule(scheduler)
        elif choice == 2:
            view_tasks(scheduler)
        elif choice == 3:
            interactive_edit_task(scheduler)
        elif choice == 4:
            interactive_remove_task(scheduler)
        elif choice == 5:
            break
        else:
            click.secho("Invalid option!", fg="red")
