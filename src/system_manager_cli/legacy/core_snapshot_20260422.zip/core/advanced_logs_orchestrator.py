# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.

"""
Advanced Logs Orchestrator for System Manager CLI

Coordinates advanced log analysis features, integrating logs_cli with core modules.
Handles option 1: Analyze current directory and generate reports.
Handles option 2: Live monitoring with alerts and incident logging.
"""

from typing import Optional, Dict, Any
import json
import time
import threading
from datetime import datetime
from pathlib import Path
from logs_cli import analyze_logs, LogAnalysisEngine, LogLevel
from core.advanced_reporter import AdvancedReporter
from core.recommender import Recommender
from core.live_monitor import LiveLogMonitor
from core.health_monitor import HealthMonitor
from tqdm import tqdm
import os


class AdvancedLogsOrchestrator:
    def __init__(self):
        self.reporter = AdvancedReporter()

    def run_option_1(
        self,
        ai_enabled: bool = True,
        email_enabled: bool = True,
        user_email: Optional[str] = None
    ) -> str:
        """
        Option 1: Analyze current directory, generate JSON report with AI solutions,
        and send email notification.

        Args:
            ai_enabled: Enable AI recommendations
            email_enabled: Enable email notifications
            user_email: User's email for notifications

        Returns:
            str: Path to the generated report
        """
        print("🔍 Analyzing logs in current directory...")

        # Show progress during analysis
        with tqdm(total=100, desc="Analyzing Logs", unit="%") as pbar:
            # Start analysis with reasonable limits to prevent overwhelming
            result = analyze_logs('', use_cwd=True, limit=1000, size_threshold=1024*1024)  # 1MB per file, max 1000 files
            pbar.update(80)  # Assume analysis takes most time

            if not result:
                pbar.update(20)
                print("❌ No logs found or analysis failed.")
                return ""

            pbar.update(20)

        print("📊 Generating advanced report with AI solutions...")

        # Generate JSON report with AI and email
        report_path = self.reporter.generate_json_report(
            analysis_result=result,
            ai_enabled=ai_enabled,
            email_enabled=email_enabled,
            user_email=user_email
        )

        return report_path

    def run_option_2(
        self,
        ai_enabled: bool = True,
        email_enabled: bool = True,
        user_email: Optional[str] = None,
        log_path: str = "",
        use_cwd: bool = True
    ) -> None:
        """
        Option 2: Live log monitoring with alerts and incident logging.

        Continuously monitors logs and sends alerts for critical issues and errors.
        Saves incidents to JSON files and provides AI solutions.
        Includes health monitoring for CPU, RAM, and disk usage alerts.
        Supports Ctrl+C for clean shutdown.

        Args:
            ai_enabled: Enable AI recommendations for incidents
            email_enabled: Enable email notifications for incidents
            user_email: User's email for notifications
            log_path: Path to monitor (ignored if use_cwd=True)
            use_cwd: Monitor current working directory
        """
        print("🔍 Starting live log monitoring with health checks...")
        print("Monitoring for CRITICAL and ERROR level issues")
        print("Health alerts: CPU, RAM, Disk usage monitoring enabled")
        print("Daily filtering: Only today's incidents will be monitored")
        print("Press Ctrl+C to stop monitoring\n")

        # Initialize monitoring with integrated health checks
        monitor = LiveLogMonitor(
            ai_enabled=ai_enabled,
            email_enabled=email_enabled,
            user_email=user_email,
            reporter=self.reporter
        )
        self.live_monitor = monitor

        try:
            monitor.start_monitoring(log_path=log_path, use_cwd=use_cwd)
        except KeyboardInterrupt:
            # ✅ ISSUE #4 FIX: Clean handling of Ctrl+C at orchestrator level
            print("\n🛑 Monitoring stopped by user.")
            monitor.stop_monitoring()
        except Exception as e:
            print(f"❌ Monitoring error: {e}")
            monitor.stop_monitoring()


