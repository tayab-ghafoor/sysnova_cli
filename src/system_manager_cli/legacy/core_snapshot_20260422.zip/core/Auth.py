# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
def require_login() -> bool:
    """Require a logged-in user for protected actions."""
    if not is_user_logged_in():
        click.secho("❌ You must be logged in to perform this action.", fg='red')
        return False
    return True

def is_user_logged_in() -> bool:
    """Check if a user is currently logged in"""
    return current_user['email'] is not None and current_user['token'] is not None


def _complete_login(login_result: dict[str, str]) -> None:
    """Store login state for the current session."""
    current_user['email'] = login_result['email']
    current_user['name'] = login_result['name']
    current_user['token'] = login_result['token']


def _run_password_reset_flow(default_email: str = "") -> bool:
    """Run the forgot-password flow and return True on successful reset."""
    reset_email = click.prompt('Enter your registered email', default=default_email)
    reset_result = auth_manager.request_password_reset(reset_email)

    if not reset_result['success']:
        click.secho(reset_result['message'], fg='red')
        logger.warning(f"Password reset request failed for {reset_email}: {reset_result['message']}")
        return False

    click.secho(reset_result['message'], fg='green')
    reset_code = click.prompt('Enter code')

    while True:
        new_password = click.prompt(
            'Enter new password (min 8 chars, 1 uppercase, 1 digit)',
            hide_input=True
        )
        confirm_password = click.prompt('Confirm password', hide_input=True)

        if new_password != confirm_password:
            click.secho("Passwords don't match. Try again.", fg='red')
            continue
        break

    reset_password_result = auth_manager.reset_password_with_code(
        reset_email,
        reset_code,
        new_password,
    )

    if reset_password_result['success']:
        click.secho(reset_password_result['message'], fg='green')
        return True

    click.secho(reset_password_result['message'], fg='red')
    logger.warning(
        f"Password reset verification failed for {reset_email}: "
        f"{reset_password_result['message']}"
    )
    return False


def _prompt_login_with_reset() -> dict[str, Any]:
    """Prompt for login and offer a password reset flow on authentication failure."""
    while True:
        email = click.prompt('📧 Enter your email')
        password = click.prompt('🔐 Enter your password', hide_input=True)

        result = auth_manager.login(email, password)
        if result['success']:
            return result

        user_exists = email in auth_manager.users
        failure_message = "Incorrect password" if user_exists else result['message']
        click.secho(f"\n{failure_message}", fg='red')
        logger.warning(f"Login failed for {email}: {result['message']}")

        click.echo("\n1. Try Again")
        click.echo("2. Forgot Password\n")
        choice = click.prompt("Select option", type=click.Choice(['1', '2']), default='1')

        if choice == '1':
            continue

        _run_password_reset_flow(email)
        return {'success': False, 'message': 'Password reset flow completed'}

def require_login(func):
    """Decorator to require login for commands"""
    def wrapper(*args, **kwargs):
        if not is_user_logged_in():
            click.secho("❌ You must login first!", fg='red')
            return
        return func(*args, **kwargs)
    wrapper.__name__ = func.__name__
    wrapper.__doc__ = func.__doc__
    return wrapper



