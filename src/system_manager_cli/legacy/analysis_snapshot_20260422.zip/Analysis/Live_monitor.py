# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
# core/live_monitor.py
"""
Live Monitor Module for System Manager CLI

Enhances streaming with health checks and daily filtering.
"""

from typing import Optional, Dict, Any
import json
import time
import threading
from datetime import datetime, date
from pathlib import Path
from logs_cli import analyze_logs, LogAnalysisEngine, LogLevel
from .advanced_reporter import AdvancedReporter
from .recommender import Recommender
from .health_monitor import HealthMonitor


class LiveLogMonitor:
    """Live log monitoring with incident detection, alerting, health checks, and daily filtering."""

    def __init__(
        self,
        ai_enabled: bool = True,
        email_enabled: bool = True,
        user_email: Optional[str] = None,
        reporter: Optional[AdvancedReporter] = None
    ):
        self.ai_enabled = ai_enabled
        self.email_enabled = email_enabled
        self.user_email = user_email
        self.reporter = reporter or AdvancedReporter()
        self.monitoring = False
        self.incidents_file = Path("reports/live_incidents.json")
        self.incidents_file.parent.mkdir(exist_ok=True)
        self.processed_entries = set()  # Track processed log entries
        self.start_time = datetime.now()
        self.health_monitor = HealthMonitor()  # Add health monitoring
        self.today = date.today()  # For daily filtering

    def start_monitoring(self, log_path: str = "", use_cwd: bool = True) -> None:
        """Start live monitoring of logs with health checks and proper Ctrl+C handling."""
        self.monitoring = True
        target_path = str(Path.cwd()) if use_cwd else log_path

        print(f"📂 Monitoring: {target_path}")
        print(f"🕐 Started at: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print("🎯 Alerting on: CRITICAL, ERROR levels")
        print("📧 Email alerts:", "Enabled" if self.email_enabled else "Disabled")
        print("🤖 AI solutions:", "Enabled" if self.ai_enabled else "Disabled")
        print("❤️ Health checks: Enabled")
        print("📅 Daily filtering: Enabled (only today's incidents)")
        print("-" * 60)

        # Initialize incidents file if it doesn't exist
        if not self.incidents_file.exists():
            self._save_incidents({"incidents": [], "start_time": self.start_time.isoformat()})

        # Start monitoring in a separate thread to allow keyboard interrupt
        # Note: stream() naturally starts from current file position, so only new entries are captured
        monitor_thread = threading.Thread(target=self._monitor_loop, args=(target_path,))
        monitor_thread.daemon = True
        monitor_thread.start()

        # Start health check thread
        health_thread = threading.Thread(target=self._health_check_loop)
        health_thread.daemon = True
        health_thread.start()

        # Keep main thread alive with proper Ctrl+C handling
        # ✅ ISSUE #4 FIX: Improved Ctrl+C handling for live monitor
        try:
            while self.monitoring:
                time.sleep(0.5)  # Reduced sleep for faster response to Ctrl+C
        except KeyboardInterrupt:
            print("\n🛑 Stopping live monitoring...")
            self.monitoring = False
            # Give threads time to stop cleanly
            monitor_thread.join(timeout=2)
            health_thread.join(timeout=2)
            print("✅ Live monitoring stopped.")

    def stop_monitoring(self) -> None:
        """Stop live monitoring."""
        self.monitoring = False
        print(f"\n📊 Monitoring stopped. Total incidents logged: {self._get_incident_count()}")

    def _monitor_loop(self, target_path: str) -> None:
        """Main monitoring loop using stream-follow with daily filtering."""
        engine = LogAnalysisEngine(target_path, size_threshold=1024*1024)

        try:
            for entry, alert in engine.stream(
                level_filter=None,
                keyword_filter=None,
                alert_threshold=1,
                alert_window_seconds=60
            ):
                if not self.monitoring:
                    break

                # Daily filtering: only process entries from today
                if not self._is_today(entry):
                    continue

                if entry.level in [LogLevel.CRITICAL, LogLevel.ERROR]:
                    entry_key = f"{entry.timestamp}_{entry.message}_{entry.level}"
                    if entry_key not in self.processed_entries:
                        self.processed_entries.add(entry_key)
                        self._handle_incident(entry)

                if alert:
                    print(f"⚠️ {alert}")

        except Exception as e:
            print(f"⚠️ Monitoring stream error: {e}")

    def _health_check_loop(self) -> None:
        """Periodic health checks."""
        while self.monitoring:
            try:
                health_results = self.health_monitor.check_system_health()
                if health_results['alerts']:
                    # Log health alerts as incidents
                    for alert in health_results['alerts']:
                        incident = {
                            "timestamp": health_results['timestamp'],
                            "level": "HEALTH_ALERT",
                            "message": alert,
                            "source": "system_health",
                            "detected_at": datetime.now().isoformat(),
                            "ai_solution": "Check system resources and optimize usage."
                        }
                        self._handle_incident(incident)
                        self.health_monitor.display_health(health_results)
                time.sleep(300)  # Check every 5 minutes
            except Exception as e:
                print(f"⚠️ Health check error: {e}")
                time.sleep(60)

    def _is_today(self, entry) -> bool:
        """Check if the log entry is from today (daily filtering)."""
        if entry.timestamp:
            return entry.timestamp.date() == self.today
        return True  # If no timestamp, process anyway

    def _handle_incident(self, entry) -> None:
        """Handle a detected incident from either log stream or health checks."""
        # Handle both log entry objects and dict incidents (from health checks)
        if isinstance(entry, dict):
            # Direct dict incident (from health checks)
            incident = entry
            # Don't reprocess if already in correct format
            self._save_incident(incident)
            if self.email_enabled and self.user_email:
                self._send_incident_alert(incident)
            
            # Display incident
            level_color = "🔴" if incident['level'] == "CRITICAL" else "🟠" if incident['level'] == "ERROR" else "❤️"
            print(f"{level_color} {incident['level']}: {incident['message'][:100]}...")
            if self.ai_enabled and "ai_solution" in incident:
                print(f"   🤖 Solution: {incident['ai_solution'][:100]}...")
        else:
            # Log entry object from stream
            incident = {
                "timestamp": entry.timestamp.isoformat() if entry.timestamp else datetime.now().isoformat(),
                "level": entry.level.value if hasattr(entry.level, 'value') else str(entry.level),
                "message": entry.message,
                "source": getattr(entry, 'source', 'unknown'),
                "detected_at": datetime.now().isoformat()
            }

            # Get AI solution if enabled
            if self.ai_enabled:
                try:
                    ai_solution = self._get_ai_solution_for_incident(entry)
                    incident["ai_solution"] = ai_solution
                except Exception:
                    incident["ai_solution"] = "AI solution unavailable"

            # Save incident to JSON
            self._save_incident(incident)

            # Send email alert if enabled
            if self.email_enabled and self.user_email:
                self._send_incident_alert(incident)

            # Display incident
            level_color = "🔴" if incident['level'] == "CRITICAL" else "🟠" if incident['level'] == "ERROR" else "❤️"
            print(f"{level_color} {incident['level']}: {incident['message'][:100]}...")
            if self.ai_enabled and "ai_solution" in incident:
                print(f"   🤖 Solution: {incident['ai_solution'][:100]}...")

    def _get_ai_solution_for_incident(self, entry) -> str:
        """Get AI solution for an incident from log entry object."""
        try:
            recommender = Recommender()
            solutions = recommender.get_ai_solutions([{
                "level": entry.level.value if hasattr(entry.level, 'value') else str(entry.level),
                "message": entry.message
            }])
            # solutions is a dict mapping message to solution
            return solutions.get(entry.message, "No solution available")
        except Exception:
            return "AI solution service unavailable"

    def _save_incident(self, incident: Dict[str, Any]) -> None:
        """Save incident to JSON file."""
        try:
            incidents_data = self._load_incidents()
            incidents_data["incidents"].append(incident)
            self._save_incidents(incidents_data)
        except Exception as e:
            print(f"⚠️ Failed to save incident: {e}")

    def _send_incident_alert(self, incident: Dict[str, Any]) -> None:
        """Send email alert for incident."""
        try:
            subject = f"🚨 Log Incident Alert: {incident['level']}"

            body = f"""
Log Incident Detected!

Time: {incident['timestamp']}
Level: {incident['level']}
Message: {incident['message']}

AI Solution: {incident.get('ai_solution', 'Not available')}

This incident has been logged to: {self.incidents_file}
"""

            # Use the reporter's email functionality
            success = self.reporter._send_email_directly(
                subject, body, self.user_email, str(self.incidents_file)
            )

            if success:
                print("📧 Alert email sent")
            else:
                print("⚠️ Failed to send alert email")

        except Exception as e:
            print(f"⚠️ Email alert failed: {e}")

    def _load_incidents(self) -> Dict[str, Any]:
        """Load incidents from JSON file."""
        try:
            if self.incidents_file.exists():
                with open(self.incidents_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except Exception:
            pass
        return {"incidents": [], "start_time": self.start_time.isoformat()}

    def _save_incidents(self, data: Dict[str, Any]) -> None:
        """Save incidents to JSON file."""
        try:
            with open(self.incidents_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"⚠️ Failed to save incidents file: {e}")

    def _get_incident_count(self) -> int:
        """Get total number of incidents."""
        try:
            data = self._load_incidents()
            return len(data.get("incidents", []))
        except Exception:
            return 0