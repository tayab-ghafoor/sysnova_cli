# Legacy archive module.
# Archived on 2026-04-22 during the architecture cleanup pass.
# Moved out of the active package because it is not part of the current
# CLI -> app -> domain -> reporting execution flow.
# Kept for historical reference only; do not import from active code.
import click
from system_manager_cli.config.config import Config





def notify_new_report_available() -> None:
    """Notify users at startup if a recent report exists."""
    if not Config.REPORTS_DIR.exists():
        return

    reports = sorted(
        Config.REPORTS_DIR.glob('log_report_*.json'),
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not reports:
        return

    click.secho(f"📄 New Report Available: {reports[0].name}", fg='green')